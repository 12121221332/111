---
AIGC:
  ContentProducer: '001191110102MAD55U9H0F10002'
  ContentPropagator: '001191110102MAD55U9H0F10002'
  Label: '1'
  ProduceID: 'fea47c41-e250-4b4a-9f0d-e8137d45b1f5'
  PropagateID: 'fea47c41-e250-4b4a-9f0d-e8137d45b1f5'
  ReservedCode1: '29e39083-b388-4118-96ab-7c3dc0ffb550'
  ReservedCode2: '29e39083-b388-4118-96ab-7c3dc0ffb550'
---

# AIDD 靶点-小分子虚拟筛选系统 — 完整操作手册

> 换电脑时，按本文档从上到下操作一遍即可恢复全部功能。

---

## 系统概览

本系统已从模拟数据升级为**真实数据**，三个数据层次：

| 层次 | 数据源 | 说明 | 状态 |
|------|--------|------|------|
| A | **DGIdb API** | 真实靶点-药物关联数据（基因名→已知药物+评分+作用类型） | ✅ 已接入 |
| B | **PubChem API** | 真实分子描述符（分子量/LogP/氢键供体/受体/SMILES） | ✅ 已接入 |
| C | **AutoDock Vina** | 真实分子对接打分（需额外安装，可选） | ⚠️ 可选 |

---

## 一、环境安装

### 1.1 安装 Python

1. 去 https://www.python.org/downloads/ 下载 Python 3.10 或以上版本
2. 安装时**勾选 "Add Python to PATH"**（重要）
3. 安装完成后，打开终端（Windows 按 Win+R 输入 cmd），验证：
   ```
   python --version
   ```

### 1.2 安装依赖库

打开终端，复制粘贴执行：

```bash
pip install streamlit pandas numpy plotly requests -i https://pypi.tuna.tsinghua.edu.cn/simple
```

> 如果你电脑上 `pip` 命令不好使，换成 `py -m pip install ...` 或 `python -m pip install ...`

验证安装成功：
```bash
python -c "import streamlit, pandas, numpy, plotly, requests; print('全部安装成功')"
```

### 1.3 安装 AutoDock Vina（可选，层次C）

如需真实分子对接打分功能，Windows 推荐用预编译二进制 + conda 依赖的方案：

**步骤 1：下载 Vina 预编译二进制**

1. 下载以下两个文件：
   - https://github.com/ccsb-scripps/AutoDock-Vina/releases/download/v1.2.7/vina_1.2.7_win.exe
   - https://github.com/ccsb-scripps/AutoDock-Vina/releases/download/v1.2.7/vina_split_1.2.7_win.exe
2. 在项目目录下创建 `vina` 文件夹，把两个 exe 放进去
   （最终路径应为 `D:\nobody\vina\vina.exe`）

**步骤 2：创建 conda 环境并安装依赖**

```bash
# 需要 Miniconda/Anaconda
conda create -n vina_env python=3.10 -y
conda activate vina_env
conda install -c conda-forge rdkit -y
pip install meeko scipy gemmi streamlit pandas numpy plotly requests openai -i https://pypi.tuna.tsinghua.edu.cn/simple
```

**步骤 3：用 vina_env 环境运行本系统**

```bash
conda activate vina_env
py -m streamlit run app.py
```

不安装 Vina 也不影响层次 A 和 B 的使用。

---

## 二、获取免费 API Key

系统内置 3 个模型服务，推荐用**智谱 GLM-4-Flash**（永久免费）。

### 2.1 智谱 GLM-4-Flash（推荐，永久免费）

1. 打开 https://bigmodel.cn
2. 右上角"注册/登录"，手机号或微信扫码注册
3. 登录后，点右上角头像 → **控制台**
4. 左侧菜单找到 **"API Keys"**
5. 点 **"新增 API Key"** → 起个名字 → 确认
6. 立刻复制生成的 `sk-` 开头的密钥保存好（关掉就看不到了）
7. 新用户注册送 2000 万 Token，glm-4-flash 模型永久免费

### 2.2 DeepSeek（备选，注册送免费额度）

1. 打开 https://platform.deepseek.com
2. 注册登录 → 左侧 "API Keys" → 创建 API Key
3. 复制 `sk-` 开头的密钥

### 2.3 自定义模型（支持任意兼容 OpenAI 格式的 API）

在网站侧边栏选"自定义"，填入 API 地址和模型名即可。

---

## 三、完整代码

> 以下为 `app.py` 的完整内容。换电脑时，把这段代码保存为 `app.py` 即可。
> 代码较长，见同目录下的 `app.py` 文件。

代码结构：

- `query_dgidb_interactions()` — 层次A：查询 DGIdb 真实靶点-药物数据
- `query_pubchem_properties()` — 层次B：查询 PubChem 真实分子属性
- `check_vina_available()` / `run_vina_docking()` — 层次C：AutoDock Vina 对接
- `call_llm()` — AI 助手的大模型调用
- `main()` — Streamlit 主界面

---

## 四、运行步骤

1. 打开终端（Windows: Win+R → 输入 cmd）

2. 进入项目目录：
   ```bash
   cd D:\nobody
   ```

3. 启动网站：
   ```bash
   py -m streamlit run app.py
   ```
   （如果 `py` 不好使，换成 `python -m streamlit run app.py`）

4. 浏览器会自动打开 http://localhost:8501

5. 在网页左侧边栏：
   - 选择"智谱 GLM-4-Flash（免费）"
   - 粘贴你的 API Key

6. 使用流程：
   - 点左侧"2. 靶点查询" → 输入基因名（如 EGFR）→ 点"查询真实数据"
   - 系统自动从 DGIdb 查询真实药物相互作用 + 从 PubChem 查询真实分子属性
   - 点左侧"3. 结果看板" → 查看筛选结果、用滑块筛选、Lipinski 检查
   - 点左侧"4. AI 助手" → 向 AI 提问分析

---

## 五、数据来源说明

### 层次A：DGIdb（药物-基因相互作用数据库）

- 官网：https://dgidb.org
- API：https://dgidb.org/api/graphql （GraphQL）
- 数据内容：靶点基因名、药物名称、相互作用评分、作用类型（抑制剂/激动剂等）、数据来源、是否 FDA 获批
- 免费，无需注册，直接调用 API

### 层次B：PubChem（分子属性数据库）

- 官网：https://pubchem.ncbi.nlm.nih.gov
- API：https://pubchem.ncbi.nlm.nih.gov/rest/pug/ （REST API）
- 数据内容：分子量、XLogP、氢键供体数、氢键受体数、SMILES、InChIKey、CID
- 免费，无需注册，直接调用 API

### 层次C：AutoDock Vina（分子对接）

- 官网：https://github.com/ccsb-scripps/AutoDock-Vina
- Windows 安装：下载 `vina_1.2.7_win.exe` 预编译二进制 + conda 安装 rdkit/meeko
- 数据内容：分子对接打分（kcal/mol，越负越好）、对接姿态
- 需要受体蛋白 PDBQT 文件，计算耗时 1-10 分钟/分子

---

## 六、换电脑速查清单

换电脑时，依次完成以下步骤：

| 步骤 | 操作 | 命令/链接 |
|------|------|-----------|
| 1 | 安装 Python 3.10+ | https://www.python.org/downloads/ |
| 2 | 安装依赖库 | `pip install streamlit pandas numpy plotly requests -i https://pypi.tuna.tsinghua.edu.cn/simple` |
| 3 | 把 app.py 复制到新电脑 | 代码见项目文件 |
| 4 | 启动 | `py -m streamlit run app.py` |
| 5（可选） | 下载 vina.exe | 放到项目 `vina/` 目录下，见 1.3 节 |

API Key 不需要重新申请，同一个 Key 换电脑也能用。DGIdb 和 PubChem 的 API 不需要 Key，直接调用。

---

## 七、常见问题

**Q: 启动报错 "No module named 'streamlit'"**
A: 依赖没装好，重新执行第二步的 pip install 命令

**Q: AI 助手提示"API 调用失败（HTTP 401）"**
A: API Key 不对或过期，去智谱控制台重新创建一个

**Q: AI 助手提示"网络连接失败"**
A: 检查网络是否正常，公司内网可能需要配代理

**Q: glm-4-flash 真的免费吗？**
A: 是的，该模型永久免费，智谱新用户注册还送 2000 万 Token 其他模型额度

**Q: 端口 8501 被占用怎么办？**
A: 用 `py -m streamlit run app.py --server.port 8502` 指定其他端口

**Q: DGIdb 查询返回 0 条结果**
A: 检查基因名拼写是否正确（如 EGFR 而非 egfr），或取消"只查已获批药物"试试

**Q: PubChem 查不到某些药物的分子属性**
A: 部分药物（如复方药、盐形式）在 PubChem 可能查不到，这是正常现象

**Q: AutoDock Vina 对接计算报错**
A: 确认 vina.exe 已下载到 `vina/` 目录，且 conda vina_env 环境中已安装 rdkit 和 meeko。上传的受体文件必须是 PDBQT 格式（可用 AutoDockTools 或 meeko 从 PDB 转换）

> AI生成