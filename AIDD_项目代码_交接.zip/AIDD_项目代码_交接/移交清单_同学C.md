# 移交清单（同学 B → 同学 C 打包/部署）

> 交接日期：2026-11-19 · 评审/测试/参数核查/可复现性已完成（阶段 1–4）
> 本清单汇总：环境启动、已修问题与新基线、待办移交、已知告警、答辩数字口径卡。
> 配套文档：[运行手册_B.md](运行手册_B.md) · [参数合理性报告.md](参数合理性报告.md) · tests/测试用例_阶段2/3/4.md

## 一、环境与启动（已验证）

单一 Python 3.12.10 环境即可同时跑 app 与 sci_core，无需双环境。

```bash
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
cd review_project
python -m streamlit run app.py
# 浏览器打开 http://localhost:8501
```

- requirements.txt 13 个包全部 `==` 精确锁版，与本机实测一致（streamlit 1.67.0 / pandas 3.1.1 / numpy 2.5.5 / scikit-learn 1.9.1 / rdkit 2026.9.2 / xgboost 3.4.1 等）。
- Vina 二进制随包：`review_project/vina/vina.exe`，无需另装。
- 演示数据：`review_project/EGFR_approved_full.csv`（71 条）；页面 02 上传 tab →「📂 加载项目目录中的 EGFR 示例数据」→**再点「✅ 载入数据」**（两步，缺一页面 03 无数据）。
- ChEMBL Benchmark：`review_project/chembl_egfr_benchmark_clean.csv`（105 条）+ `chembl_docking_results.csv`（页面 07 自动检测）。

## 二、已修问题汇总（阶段 1–4）

崩溃/逻辑级（阶段 2）：BUG-01 PubChem 字符串字段转型、BUG-03 上传 CSV 数值强转、BUG-04 硬过滤 RDKit 解析校验、待核查-04 PAINS import 修复。
显示/体验级：BUG-02 对接表合并渲染、UX-01 对接结果切页保留、UX-02 报告 NaN/None → N/A。
可复现：REPRO-01 Vina `--seed 42`（app + sci_core 全覆盖）。
参数/口径（阶段 3 A 档）：A1 已知抑制剂 28 名单 + 首词匹配、A2 GDSC 叙事降级、A3 ML 纳入综合评分、A4 GDSC 词边界正则、A5 EF 分母改库内重叠、A6 筛选缺失保留。
性能（阶段 4）：QED/PAINS/ML/描述符按 SMILES 缓存（`st.cache_data`）、PAINS catalog `st.cache_resource`、Benchmark B 结果缓存。等价性逐值验证通过，浏览器结果不变。

## 三、修复后新基线（答辩/演示用，替代交接说明旧数字）

| 项目 | 新基线 |
|------|--------|
| 示例数据 | 71 条 → Stage 1 保留 50/71（排除 21 条无效 SMILES，Pass 34） |
| 示例路径 Top1 | AFATINIB 85.3（High）；Top5 全 EGFR-TKI（AFATINIB 85.3 / DACOMITINIB ANHYDROUS 84.6 / MOBOCERTINIB 75.2 / ERLOTINIB 74.4 / GEFITINIB 71.2） |
| 在线路径 Top1 | AFATINIB 77.1；LIDOCAINE 降至 32/49（39.9） |
| LIDOCAINE 示例排名 | 34/50（39.7） |
| 综合评分权重 | Docking 30% + ML 30% + QED 15% + Lipinski 10% + DGIdb 15%（活性证据 60%） |
| Benchmark A（示例） | n=50，阳性 25，ROC-AUC 0.368，EF@5% 2.0（页面如实显示"富集效果有限"警示） |
| Benchmark B（ChEMBL 105） | Data-driven ROC-AUC 0.845±0.089；Docking 单维 0.796；消融 Docking+QED 0.846 |
| ML 模型 | ECFP4+RF，ChEMBL EGFR 12k 分子，scaffold-CV ROC-AUC 0.948 |
| 大规模筛选 | 190,966 库 → top 2,000；结构富集 57.5×（Tanimoto>0.4 口径）；对接 100 分子最佳 -9.14 |
| GDSC（随包旧结果） | 288 敏感系 / NSCLC 20；⚠ 含 VEGFR 误匹配，块 6 重跑后应为 283 系 / 8 药 |

## 四、待办移交

**B 档（需数据/重跑，同学 A 主导，C 协助）**
1. 重跑块 6（GDSC2 xlsx）再生 `results_gdsc/*`，验证 283 系 / 8 药口径；重跑后页面 02 的 ⚠ VEGFR 降级提示自动消失。
2. 重跑块 5（pubchem_library.csv）再生 `summary.json` 的有效 EF（A5 已修分母为库内重叠）；或补交 library 文件由本机重算。
3. Benchmark A 固定数据集快照（DGIdb 在线评分随时间漂移，AUC 不可复现，需快照固定）。
4. （可选，做实突变叙事）下载 GDSC COSMIC 突变注释，按 EGFR 突变状态分层比较 Gefitinib/Erlotinib IC50。
5. ML 模型重训或导出 ONNX（消除跨版本 pickle 告警，见下）。

**C 档（答辩口径/文档，同学 C）**
6. 答辩数字口径卡（见第五节）写入答辩稿，三个核心数字分别标注验证对象。
7. 所有 ⚠ 自定义阈值在 METHODOLOGY.md 补"项目自定义"声明（权重、IC50<1µM 高敏感线、Tanimoto>0.4、EF 截断等，逐项出处见 参数合理性报告.md 第六节）。
8. GDSC 叙事采用降级版（参数合理性报告.md 4.4）：不宣称"EGFR 突变驱动精准用药"，改为"8 个 EGFR/ErbB 药在 283 系达 IC50<1µM，NSCLC 最多（20/88），Afatinib/Osimertinib 覆盖最多 NSCLC 敏感系，与临床 TKI 优先用于 NSCLC 一致；突变分层列为后续工作"。

## 五、答辩数字口径卡（关键，避免被问倒）

| 数字 | 验证对象 | 口径/限制 | 不能说成 |
|------|---------|-----------|----------|
| **0.948** | ML 活性模型（ECFP4+RF） | ChEMBL EGFR 12k 分子，scaffold-split CV ROC-AUC；靶点特异性活性预测 | 整个系统的筛选准确率 |
| **57.5×** | 大规模库结构富集 | top2000 与 15 个参照 EGFR-TKI 的 ECFP4 Tanimoto>0.4 占比 2.3% vs 随机 0.04%；**结构相似性富集，非活性召回** | 活性分子富集倍数 / 命中率 |
| **0.845±0.089** | Benchmark B 数据驱动融合 | ChEMBL 105 分子实验 IC50 标签，Docking+QED+Lipinski，Pipeline+5×10 CV；独立实验标签 | 与 0.948 混为一谈（不同数据/模型） |
| **0.368** | Benchmark A 启发式排序 sanity check | 示例 50 条，已知抑制剂名称匹配标签，**刻意排除 ML 防泄漏**；AUC<0.5 如实显示"富集效果有限" | 系统排序能力差 / 与生产评分混淆（生产含 ML，Top5 全 TKI） |

要点：Benchmark A 低 AUC 是**诚实结果**——它验证的是不含 ML 的启发式融合组件本身（防标签泄漏），而生产排名（页面 03）含 ML 活性证据，Top5 全为 EGFR-TKI。两者口径不同，答辩时主动说明而非回避。

## 六、已知告警（非错误，打包时保留即可）

- **跨版本 pickle**：`sci_core/results/final_models.pkl` 由 sklearn 1.7.2 训练，1.9.1 加载有 InconsistentVersionWarning，实测预测正常（Erlotinib/Gefitinib p≈0.987，乙醇 p≈0.010，非法 SMILES NaN）。
  - 消除步骤（同学 A）：`cd sci_core && python train_models.py --seed 42` 本机重训覆盖 pkl；或训练后导出 ONNX 改 predict.py 加载路径。重训需 ChEMBL 训练数据（块 2 产物）。
- **streamlit 弃用告警**：`use_container_width` 已全量替换为 `width='stretch'`，无残留。
- **PubChem 失败查询**：不做负缓存（避免瞬时网络失败被永久缓存），重新点击查询会重试失败名；属预期行为。
- **numpy BLAS**：本机健康（矩阵乘法实测通过），交接文档中队友 A 机器的 BLAS 损坏问题在本机不存在。

## 七、测试与复现材料索引

| 文件 | 内容 |
|------|------|
| tests/测试用例_阶段2.md | 边界测试 + BUG-01~04 / REPRO-01 / UX-01 / PAINS 修复记录 |
| tests/测试用例_阶段3.md | TC3-01~16 参数审计复现 + A 档修复回归 |
| tests/测试用例_阶段4.md | TC4-01~06 性能探针 / 缓存等价 / 浏览器回归 / 可复现性核对 |
| tests/stage3_fix_verify.py | A 档修复离线回归（输出 demo/live ranking CSV） |
| tests/stage4_perf_probe.py | 各计算段耗时探针 |
| tests/stage4_cache_verify.py | 缓存版 vs 直接计算逐值等价断言 |
| tests/stage4_report_verify.py | 页面06 报告内容断言（含 ML 证据/无 nan） |
| tests/stage4_report_sample.md | 报告 Markdown 样例 |

## 八、未做（明确边界）

- LLM 功能（页面 01/05/06 的 AI 规划/对话/建议）：按用户指示搁置，仅验证无 API Key 时友好提示不崩溃；填入智谱 GLM-4-Flash Key 后的实测留待后续。
- sci_core 块 5/6 重跑：本机无 pubchem_library.csv 与 GDSC2 xlsx，app 展示用预计算结果不受影响（见 B 档）。