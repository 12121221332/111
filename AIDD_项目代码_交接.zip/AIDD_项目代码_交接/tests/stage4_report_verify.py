# -*- coding: utf-8 -*-
"""阶段4 报告下载验证：页面06 Markdown 报告含 ML 证据条目、新权重、无 nan/None 残留。

用法：python tests/stage4_report_verify.py
"""
import ast
import io
import os
import sys
import time
import warnings

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
warnings.filterwarnings('ignore')

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
APP = os.path.join(BASE, 'review_project', 'app.py')
sys.path.insert(0, os.path.join(BASE, 'sci_core'))

import numpy as np
import pandas as pd
import streamlit as st

src = open(APP, encoding='utf-8').read()
tree = ast.parse(src)
WANT = {
    'compute_composite_score', 'compute_evidence_confidence', 'build_evidence_chain',
    'apply_hard_filter', 'generate_research_report', 'generate_report_markdown',
    'compute_ml_scores', '_load_ml_scorer', '_ml_proba_one', '_qed_one', '_pains_one', '_pains_catalog',
}
pieces = []
for node in tree.body:
    if isinstance(node, ast.Assign):
        targets = [t.id for t in node.targets if isinstance(t, ast.Name)]
        if any(t.startswith('COL_') or t in ('_ml_scorer', '_ml_load_error') for t in targets):
            pieces.append(ast.get_source_segment(src, node))
    elif isinstance(node, ast.FunctionDef) and node.name in WANT:
        pieces.append(ast.get_source_segment(src, node))

ns = {'pd': pd, 'np': np, 'os': os, 'sys': sys, 'time': time, 'st': st, '__file__': APP}
exec('\n\n'.join(pieces), ns)

df = pd.read_csv(os.path.join(BASE, 'review_project', 'EGFR_approved_full.csv'))
for col in (ns['COL_SCORE'], ns['COL_MW'], ns['COL_LOGP'], ns['COL_HBD'], ns['COL_HBA'], ns['COL_DOCKING_SCORE']):
    if col in df.columns:
        df[col] = pd.to_numeric(df[col], errors='coerce')

# 复现页面03 处理链
df['Lipinski符合'] = df.apply(
    lambda r: ((r.get(ns['COL_MW'], 0) or 0) <= 500 and (r.get(ns['COL_LOGP'], 0) or 0) <= 5
               and (r.get(ns['COL_HBD'], 0) or 0) <= 5 and (r.get(ns['COL_HBA'], 0) or 0) <= 10)
    if pd.notna(r.get(ns['COL_MW'])) else None, axis=1)
df['QED类药性'] = [ns['_qed_one'](str(s)) if pd.notna(s) and str(s).strip() else None for s in df[ns['COL_SMILES']]]
df['PAINS警示'] = [ns['_pains_one'](str(s)) if pd.notna(s) and str(s).strip() else None for s in df[ns['COL_SMILES']]]
df, _ = ns['apply_hard_filter'](df)
df[ns['COL_ML_SCORE']] = ns['compute_ml_scores'](df[ns['COL_SMILES']])
df[ns['COL_COMPOSITE_SCORE']] = df.apply(lambda r: ns['compute_composite_score'](r), axis=1)
df[ns['COL_EVIDENCE_CONFIDENCE']] = df.apply(lambda r: ns['compute_evidence_confidence'](r), axis=1)
df = df.sort_values(ns['COL_COMPOSITE_SCORE'], ascending=False, na_position='last')

report = ns['generate_research_report'](df, 'EGFR', 'EGFR 抑制剂候选筛选', top_n=10)
md = ns['generate_report_markdown'](report)

out = os.path.join(BASE, 'tests', 'stage4_report_sample.md')
open(out, 'w', encoding='utf-8').write(md)

assert 'ML 活性证据' in md, '报告缺少 ML 证据条目'
assert 'ECFP4' in md, '报告缺少 ML 模型来源'
assert '30%' in md, '报告缺少新权重'
assert 'nan' not in md.lower().replace('finance', ''), '报告含 nan 残留'
assert '| None |' not in md, '报告含 None 残留'
top1 = report['top_candidates'][0]
assert top1['name'] == 'AFATINIB', f"Top1 应为 AFATINIB，实际 {top1['name']}"
print(f"ASSERT OK: 报告含 ML 证据 / 新权重 / 无 nan/None；Top1={top1['name']} {top1['score']}")
print(f'报告样例已写出：{out}（{len(md)} 字符）')