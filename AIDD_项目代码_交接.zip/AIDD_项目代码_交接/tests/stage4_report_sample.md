# AIDD 筛选科研报告

**靶点：** EGFR
**研究目标：** EGFR 抑制剂候选筛选
**生成时间：** 2026-11-19 16:54:44

## 概览

| 指标 | 值 |
|------|-----|
| 候选药物总数 | 50 |
| 获批药物数 | 50 |
| Lipinski 通过数 | 29 |
| PAINS 通过数 | 48 |
| QED 平均值 | 0.384 |

## Top 10 候选药物

| 排名 | 药物名称 | 综合评分 | 置信度 | 分子量 | LogP | QED | 对接评分 | 获批 |
|------|----------|----------|--------|--------|------|------|----------|------|
| 1 | AFATINIB | 85.3 | High | 485.9 | 3.60 | 0.457 | N/A | True |
| 2 | DACOMITINIB ANHYDROUS | 84.6 | High | 469.9 | 4.40 | 0.465 | N/A | True |
| 3 | MOBOCERTINIB | 75.2 | High | 585.7 | 4.40 | 0.174 | N/A | True |
| 4 | ERLOTINIB | 74.4 | High | 393.4 | 3.30 | 0.418 | N/A | True |
| 5 | GEFITINIB | 71.2 | High | 446.9 | 4.10 | 0.518 | N/A | True |
| 6 | OSIMERTINIB | 69.8 | High | 499.6 | 3.70 | 0.311 | N/A | True |
| 7 | VANDETANIB | 69.4 | High | 475.4 | 4.90 | 0.542 | N/A | True |
| 8 | DACOMITINIB | 68.4 | High | 469.9 | 4.40 | 0.465 | N/A | True |
| 9 | OLMUTINIB | 67.7 | High | 486.6 | 4.70 | 0.352 | N/A | True |
| 10 | IBRUTINIB | 67.6 | High | 440.5 | 3.60 | 0.467 | N/A | True |

## 证据链

### #1 AFATINIB (综合评分: 85.3 | 置信度: High)

| 维度 | 数据来源 | 指标值 | 权重 | 说明 |
|------|----------|--------|------|------|
| 知识关联证据 | DGIdb | 0.855 | 15% | DGIdb 知识关联证据 — 靶点-药物关联的数据库评分，非结合强度 |
| 分子属性 | PubChem | MW=485.9, LogP=3.6, HBD=2.0, HBA=8.0 | — | 来自 PubChem 真实计算值 |
| 成药性 (QED) | RDKit QED | 0.457 | 15% | QED 类药性评估，范围 0~1，> 0.5 为良好（类药性而非活性） |
| 类药规则 (Lipinski) | Lipinski 五规则 | 4/4 全部符合 | 10% | MW≤500, LogP≤5, HBD≤5, HBA≤10 |
| 药物开发状态 | DGIdb / FDA | 已获批 | 展示信息 | 已获监管机构批准上市（已从评分中降级，仅作为开发成熟度参考） |
| 结构预测证据 | AutoDock Vina | 未计算 | 30% | 尚未进行分子对接预测 |
| ML 活性证据 | ECFP4 + RandomForest | 1.000 | 30% | ECFP4+RF 模型 (ChEMBL EGFR 12k 分子, scaffold-CV AUC 0.948) 预测的靶点活性概率，唯一靶点特异性活性证据 |
| 风险提示 | RDKit PAINS | 通过 | 过滤条件 | ✅ 通过 PAINS 筛选，无明显假阳性风险 |
| 证据置信度 | Evidence Completeness | High | — | 基于可用证据维度数量评估，High=≥4维 / Medium=2~3维 / Low=1维 |
| 综合智能评分 | AI Evidence Fusion | 85.3 / 100 | 100% | Stage 2 三类证据五指标加权融合（Structural: Docking 30% + Activity: ML 活性概率 30% + Molecular: QED 15% + Lipinski 10% + Knowledge: DGIdb 15%，项目自定义启发式），Drug Status 已降级为展示信息，PAINS 在 Stage 1 风险筛查阶段已处理 |
### #2 DACOMITINIB ANHYDROUS (综合评分: 84.6 | 置信度: High)

| 维度 | 数据来源 | 指标值 | 权重 | 说明 |
|------|----------|--------|------|------|
| 知识关联证据 | DGIdb | 0.819 | 15% | DGIdb 知识关联证据 — 靶点-药物关联的数据库评分，非结合强度 |
| 分子属性 | PubChem | MW=469.9, LogP=4.4, HBD=2.0, HBA=7.0 | — | 来自 PubChem 真实计算值 |
| 成药性 (QED) | RDKit QED | 0.465 | 15% | QED 类药性评估，范围 0~1，> 0.5 为良好（类药性而非活性） |
| 类药规则 (Lipinski) | Lipinski 五规则 | 4/4 全部符合 | 10% | MW≤500, LogP≤5, HBD≤5, HBA≤10 |
| 药物开发状态 | DGIdb / FDA | 已获批 | 展示信息 | 已获监管机构批准上市（已从评分中降级，仅作为开发成熟度参考） |
| 结构预测证据 | AutoDock Vina | 未计算 | 30% | 尚未进行分子对接预测 |
| ML 活性证据 | ECFP4 + RandomForest | 1.000 | 30% | ECFP4+RF 模型 (ChEMBL EGFR 12k 分子, scaffold-CV AUC 0.948) 预测的靶点活性概率，唯一靶点特异性活性证据 |
| 风险提示 | RDKit PAINS | 通过 | 过滤条件 | ✅ 通过 PAINS 筛选，无明显假阳性风险 |
| 证据置信度 | Evidence Completeness | High | — | 基于可用证据维度数量评估，High=≥4维 / Medium=2~3维 / Low=1维 |
| 综合智能评分 | AI Evidence Fusion | 84.6 / 100 | 100% | Stage 2 三类证据五指标加权融合（Structural: Docking 30% + Activity: ML 活性概率 30% + Molecular: QED 15% + Lipinski 10% + Knowledge: DGIdb 15%，项目自定义启发式），Drug Status 已降级为展示信息，PAINS 在 Stage 1 风险筛查阶段已处理 |
### #3 MOBOCERTINIB (综合评分: 75.2 | 置信度: High)

| 维度 | 数据来源 | 指标值 | 权重 | 说明 |
|------|----------|--------|------|------|
| 知识关联证据 | DGIdb | 1.091 | 15% | DGIdb 知识关联证据 — 靶点-药物关联的数据库评分，非结合强度 |
| 分子属性 | PubChem | MW=585.7, LogP=4.4, HBD=2.0, HBA=9.0 | — | 来自 PubChem 真实计算值 |
| 成药性 (QED) | RDKit QED | 0.174 | 15% | QED 类药性评估，范围 0~1，> 0.5 为良好（类药性而非活性） |
| 类药规则 (Lipinski) | Lipinski 五规则 | 有不符合项 | 10% | MW≤500, LogP≤5, HBD≤5, HBA≤10 |
| 药物开发状态 | DGIdb / FDA | 已获批 | 展示信息 | 已获监管机构批准上市（已从评分中降级，仅作为开发成熟度参考） |
| 结构预测证据 | AutoDock Vina | 未计算 | 30% | 尚未进行分子对接预测 |
| ML 活性证据 | ECFP4 + RandomForest | 1.000 | 30% | ECFP4+RF 模型 (ChEMBL EGFR 12k 分子, scaffold-CV AUC 0.948) 预测的靶点活性概率，唯一靶点特异性活性证据 |
| 风险提示 | RDKit PAINS | 通过 | 过滤条件 | ✅ 通过 PAINS 筛选，无明显假阳性风险 |
| 证据置信度 | Evidence Completeness | High | — | 基于可用证据维度数量评估，High=≥4维 / Medium=2~3维 / Low=1维 |
| 综合智能评分 | AI Evidence Fusion | 75.2 / 100 | 100% | Stage 2 三类证据五指标加权融合（Structural: Docking 30% + Activity: ML 活性概率 30% + Molecular: QED 15% + Lipinski 10% + Knowledge: DGIdb 15%，项目自定义启发式），Drug Status 已降级为展示信息，PAINS 在 Stage 1 风险筛查阶段已处理 |
### #4 ERLOTINIB (综合评分: 74.4 | 置信度: High)

| 维度 | 数据来源 | 指标值 | 权重 | 说明 |
|------|----------|--------|------|------|
| 知识关联证据 | DGIdb | 0.415 | 15% | DGIdb 知识关联证据 — 靶点-药物关联的数据库评分，非结合强度 |
| 分子属性 | PubChem | MW=393.4, LogP=3.3, HBD=1.0, HBA=7.0 | — | 来自 PubChem 真实计算值 |
| 成药性 (QED) | RDKit QED | 0.418 | 15% | QED 类药性评估，范围 0~1，> 0.5 为良好（类药性而非活性） |
| 类药规则 (Lipinski) | Lipinski 五规则 | 4/4 全部符合 | 10% | MW≤500, LogP≤5, HBD≤5, HBA≤10 |
| 药物开发状态 | DGIdb / FDA | 已获批 | 展示信息 | 已获监管机构批准上市（已从评分中降级，仅作为开发成熟度参考） |
| 结构预测证据 | AutoDock Vina | 未计算 | 30% | 尚未进行分子对接预测 |
| ML 活性证据 | ECFP4 + RandomForest | 0.987 | 30% | ECFP4+RF 模型 (ChEMBL EGFR 12k 分子, scaffold-CV AUC 0.948) 预测的靶点活性概率，唯一靶点特异性活性证据 |
| 风险提示 | RDKit PAINS | 通过 | 过滤条件 | ✅ 通过 PAINS 筛选，无明显假阳性风险 |
| 证据置信度 | Evidence Completeness | High | — | 基于可用证据维度数量评估，High=≥4维 / Medium=2~3维 / Low=1维 |
| 综合智能评分 | AI Evidence Fusion | 74.4 / 100 | 100% | Stage 2 三类证据五指标加权融合（Structural: Docking 30% + Activity: ML 活性概率 30% + Molecular: QED 15% + Lipinski 10% + Knowledge: DGIdb 15%，项目自定义启发式），Drug Status 已降级为展示信息，PAINS 在 Stage 1 风险筛查阶段已处理 |
### #5 GEFITINIB (综合评分: 71.2 | 置信度: High)

| 维度 | 数据来源 | 指标值 | 权重 | 说明 |
|------|----------|--------|------|------|
| 知识关联证据 | DGIdb | 0.166 | 15% | DGIdb 知识关联证据 — 靶点-药物关联的数据库评分，非结合强度 |
| 分子属性 | PubChem | MW=446.9, LogP=4.1, HBD=1.0, HBA=8.0 | — | 来自 PubChem 真实计算值 |
| 成药性 (QED) | RDKit QED | 0.518 | 15% | QED 类药性评估，范围 0~1，> 0.5 为良好（类药性而非活性） |
| 类药规则 (Lipinski) | Lipinski 五规则 | 4/4 全部符合 | 10% | MW≤500, LogP≤5, HBD≤5, HBA≤10 |
| 药物开发状态 | DGIdb / FDA | 已获批 | 展示信息 | 已获监管机构批准上市（已从评分中降级，仅作为开发成熟度参考） |
| 结构预测证据 | AutoDock Vina | 未计算 | 30% | 尚未进行分子对接预测 |
| ML 活性证据 | ECFP4 + RandomForest | 0.987 | 30% | ECFP4+RF 模型 (ChEMBL EGFR 12k 分子, scaffold-CV AUC 0.948) 预测的靶点活性概率，唯一靶点特异性活性证据 |
| 风险提示 | RDKit PAINS | 通过 | 过滤条件 | ✅ 通过 PAINS 筛选，无明显假阳性风险 |
| 证据置信度 | Evidence Completeness | High | — | 基于可用证据维度数量评估，High=≥4维 / Medium=2~3维 / Low=1维 |
| 综合智能评分 | AI Evidence Fusion | 71.2 / 100 | 100% | Stage 2 三类证据五指标加权融合（Structural: Docking 30% + Activity: ML 活性概率 30% + Molecular: QED 15% + Lipinski 10% + Knowledge: DGIdb 15%，项目自定义启发式），Drug Status 已降级为展示信息，PAINS 在 Stage 1 风险筛查阶段已处理 |

---
*本报告由 AIDD 智能决策系统自动生成。分子对接结果为 AutoDock Vina 计算预测值，非实验测得。*