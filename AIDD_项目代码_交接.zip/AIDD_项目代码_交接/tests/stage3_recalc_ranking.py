# -*- coding: utf-8 -*-
"""阶段3：离线复算页面03综合评分排名，分解各维度贡献（不启动 streamlit）。"""
import ast
import io
import sys
from pathlib import Path

import pandas as pd
from rdkit import Chem
from rdkit.Chem import QED, FilterCatalog
from rdkit.Chem.FilterCatalog import FilterCatalogParams

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'review_project' / 'app.py'

# 从 app.py 提取 COL_ 常量与评分相关函数，保证与线上代码逐字一致
tree = ast.parse(APP.read_text(encoding='utf-8'))
wanted_funcs = {'apply_hard_filter', 'compute_composite_score', 'compute_evidence_confidence'}
pieces = []
for node in tree.body:
    if isinstance(node, ast.Assign):
        tgt = node.targets[0]
        if isinstance(tgt, ast.Name) and tgt.id.startswith('COL_'):
            pieces.append(ast.get_source_segment(APP.read_text(encoding='utf-8'), node))
    elif isinstance(node, ast.FunctionDef) and node.name in wanted_funcs:
        pieces.append(ast.get_source_segment(APP.read_text(encoding='utf-8'), node))
ns = {'pd': pd}
exec('\n\n'.join(pieces), ns)

COL_ID, COL_DRUG = ns['COL_ID'], ns['COL_DRUG_NAME']
COL_SCORE, COL_MW, COL_LOGP = ns['COL_SCORE'], ns['COL_MW'], ns['COL_LOGP']
COL_HBD, COL_HBA, COL_SMILES = ns['COL_HBD'], ns['COL_HBA'], ns['COL_SMILES']
COL_COMP, COL_DOCK = ns['COL_COMPOSITE_SCORE'], ns['COL_DOCKING_SCORE']

df = pd.read_csv(ROOT / 'review_project' / 'EGFR_approved_full.csv')
print(f'载入 {len(df)} 条')

# 页面03默认筛选（与 app.py:2669-2687 一致）
df = df[(df[COL_MW].fillna(0) >= 0) & (df[COL_MW].fillna(0) <= 1000)]
df = df[(df[COL_LOGP].fillna(-99) >= -5.0) & (df[COL_LOGP].fillna(-99) <= 10.0)]
df = df[df[COL_HBD].fillna(99) <= 20]
df = df[df[COL_HBA].fillna(99) <= 20]
print(f'默认属性筛选后 {len(df)} 条')

df['Lipinski符合'] = df.apply(lambda r: (
    (r.get(COL_MW, 0) or 0) <= 500 and (r.get(COL_LOGP, 0) or 0) <= 5 and
    (r.get(COL_HBD, 0) or 0) <= 5 and (r.get(COL_HBA, 0) or 0) <= 10
) if pd.notna(r.get(COL_MW)) else None, axis=1)

params = FilterCatalogParams()
for c in (FilterCatalogParams.FilterCatalogs.PAINS_A,
          FilterCatalogParams.FilterCatalogs.PAINS_B,
          FilterCatalogParams.FilterCatalogs.PAINS_C):
    params.AddCatalog(c)
catalog = FilterCatalog.FilterCatalog(params)

qed_v, pains_v = [], []
for smi in df[COL_SMILES]:
    mol = Chem.MolFromSmiles(str(smi)) if pd.notna(smi) and str(smi).strip() else None
    qed_v.append(round(QED.qed(mol), 3) if mol else None)
    pains_v.append(('警示' if catalog.HasMatch(mol) else '通过') if mol else None)
df['QED类药性'], df['PAINS警示'] = qed_v, pains_v

df, log = ns['apply_hard_filter'](df)
print('filter_log:', log)
df[COL_COMP] = df.apply(lambda r: ns['compute_composite_score'](r), axis=1)
df['置信度'] = df.apply(lambda r: ns['compute_evidence_confidence'](r), axis=1)
df = df.sort_values(COL_COMP, ascending=False, na_position='last')

cols = [COL_DRUG, COL_COMP, '置信度', COL_SCORE, 'QED类药性', 'Lipinski符合', COL_MW, COL_LOGP]
print('\n=== Top 10 ===')
print(df[cols].head(10).to_string(index=False))

print('\n=== 维度贡献分解（无 Docking，权重归一 QED 41.7% / Lipinski 25% / DGIdb 33.3%）===')
focus = ['LIDOCAINE', 'AFATINIB', 'GEFITINIB', 'ERLOTINIB', 'OSIMERTINIB', 'LAPATINIB']
for name in focus:
    rows = df[df[COL_DRUG].str.upper() == name]
    if rows.empty:
        print(f'{name}: 未进入筛选后集合')
        continue
    r = rows.iloc[0]
    qed_pts = (r['QED类药性'] or 0) * 100 * (0.25 / 0.60)
    lip_pts = (100 if r['Lipinski符合'] else 50) * (0.15 / 0.60)
    dg_pts = min(100, r[COL_SCORE] * 100) * (0.20 / 0.60)
    rank = list(df[COL_DRUG]).index(r[COL_DRUG]) + 1
    print(f"{name:12s} rank={rank:2d} 总分={r[COL_COMP]:5.1f} | QED={r['QED类药性']:.3f}→{qed_pts:5.1f} "
          f"Lipinski={'符合' if r['Lipinski符合'] else '违反'}→{lip_pts:4.1f} "
          f"DGIdb={r[COL_SCORE]:.4f}→{dg_pts:5.1f}")

# 真 EGFR 抑制剂 vs 非肿瘤药的 QED 分布
print('\n=== 全集合 QED 分布 ===')
print(df[['QED类药性']].describe().to_string())
df[cols].to_csv(ROOT / 'tests' / 'stage3_ranking_recalc.csv', index=False, encoding='utf-8-sig')
print('\n已保存 tests/stage3_ranking_recalc.csv')