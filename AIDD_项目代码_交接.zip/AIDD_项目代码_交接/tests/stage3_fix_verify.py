# -*- coding: utf-8 -*-
"""阶段3 A档修复验证：新权重(含ML)+新名单+缺失值保留语义，离线复算两条路径。"""
import ast
import io
import sys
import warnings
from pathlib import Path

warnings.filterwarnings('ignore')
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'sci_core'))
import pandas as pd
from rdkit import Chem
from rdkit.Chem import QED, FilterCatalog
from rdkit.Chem.FilterCatalog import FilterCatalogParams
from predict import MLScorer

APP = ROOT / 'review_project' / 'app.py'
src = APP.read_text(encoding='utf-8')
tree = ast.parse(src)
wanted = {'apply_hard_filter', 'compute_composite_score', 'compute_evidence_confidence',
          'compute_benchmark_score', 'run_benchmark_enrichment', '_match_known_inhibitor'}
pieces = []
for node in tree.body:
    if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name):
        t = node.targets[0].id
        if t.startswith('COL_') or t == 'KNOWN_EGFR_INHIBITORS':
            pieces.append(ast.get_source_segment(src, node))
    elif isinstance(node, ast.FunctionDef) and node.name in wanted:
        pieces.append(ast.get_source_segment(src, node))
ns = {'pd': pd}
exec('\n\n'.join(pieces), ns)
C = lambda k: ns[k]
print('KNOWN 名单:', len(ns['KNOWN_EGFR_INHIBITORS']), '个（去重后',
      len({n.lower() for n in ns['KNOWN_EGFR_INHIBITORS']}), '）')

scorer = MLScorer(str(ROOT / 'sci_core' / 'results' / 'final_models.pkl'))
params = FilterCatalogParams()
for c in (FilterCatalogParams.FilterCatalogs.PAINS_A,
          FilterCatalogParams.FilterCatalogs.PAINS_B,
          FilterCatalogParams.FilterCatalogs.PAINS_C):
    params.AddCatalog(c)
cat = FilterCatalog.FilterCatalog(params)


def pipeline(df, label):
    # A6 新语义：缺失保留
    for col, lo, hi in [(C('COL_MW'), 0, 1000), (C('COL_LOGP'), -5.0, 10.0)]:
        m = df[col]
        df = df[m.isna() | ((m >= lo) & (m <= hi))]
    for col in (C('COL_HBD'), C('COL_HBA')):
        m = df[col]
        df = df[m.isna() | (m <= 20)]
    print(f'\n===== {label} =====')
    print(f'A6 缺失保留语义筛选后: {len(df)} 条')
    df['Lipinski符合'] = df.apply(lambda r: (
        (r.get(C('COL_MW'), 0) or 0) <= 500 and (r.get(C('COL_LOGP'), 0) or 0) <= 5 and
        (r.get(C('COL_HBD'), 0) or 0) <= 5 and (r.get(C('COL_HBA'), 0) or 0) <= 10
    ) if pd.notna(r.get(C('COL_MW'))) else None, axis=1)
    qv, pv = [], []
    for smi in df[C('COL_SMILES')]:
        mol = Chem.MolFromSmiles(str(smi)) if pd.notna(smi) and str(smi).strip() else None
        qv.append(round(QED.qed(mol), 3) if mol else None)
        pv.append(('警示' if cat.HasMatch(mol) else '通过') if mol else None)
    df['QED类药性'], df['PAINS警示'] = qv, pv
    df, log = ns['apply_hard_filter'](df)
    print('filter_log:', log)
    df[C('COL_ML_SCORE')] = scorer.predict_proba(
        [s if isinstance(s, str) else None for s in df[C('COL_SMILES')]])
    df[C('COL_COMPOSITE_SCORE')] = df.apply(lambda r: ns['compute_composite_score'](r), axis=1)
    df = df.sort_values(C('COL_COMPOSITE_SCORE'), ascending=False, na_position='last')
    cols = [C('COL_DRUG_NAME'), C('COL_COMPOSITE_SCORE'), C('COL_ML_SCORE'),
            C('COL_SCORE'), 'QED类药性', C('COL_FILTER_STATUS')]
    print('--- 新 Top 10 ---')
    print(df[cols].head(10).round(3).to_string(index=False))
    lid = df[df[C('COL_DRUG_NAME')].str.upper() == 'LIDOCAINE']
    if not lid.empty:
        rank = list(df[C('COL_DRUG_NAME')]).index(lid.iloc[0][C('COL_DRUG_NAME')]) + 1
        print(f'LIDOCAINE 新排名: {rank} / {len(df)}, 分数 {lid.iloc[0][C("COL_COMPOSITE_SCORE")]}')
    b = ns['run_benchmark_enrichment'](df)
    if b:
        print('Benchmark A (新名单+首词匹配, 启发式不含ML):',
              {k: b[k] for k in ('n_total', 'n_active', 'roc_auc', 'ef_5', 'top_1_active', 'top_5_active', 'top_10_active')})
    return df


demo = pd.read_csv(ROOT / 'review_project' / 'EGFR_approved_full.csv')
d1 = pipeline(demo, '示例数据路径 (EGFR_approved_full.csv)')
d1.to_csv(ROOT / 'tests' / 'stage3_fix_demo_ranking.csv', index=False, encoding='utf-8-sig')

live = pd.read_csv(ROOT / 'tests' / 'stage3_live_ranking_recalc.csv')
d2 = pipeline(live, 'DGIdb 在线路径 (2026-11-19 快照)')
d2.to_csv(ROOT / 'tests' / 'stage3_fix_live_ranking.csv', index=False, encoding='utf-8-sig')
print('\n已保存 tests/stage3_fix_demo_ranking.csv / stage3_fix_live_ranking.csv')