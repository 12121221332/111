# -*- coding: utf-8 -*-
"""阶段4 缓存优化等价性验证：缓存版计算必须与旧版逐值一致。

用法：python tests/stage4_cache_verify.py
断言：QED / PAINS / 描述符 / ML / Benchmark B 缓存版 == 直接计算版。
"""
import ast
import io
import os
import sys
import time
import warnings

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
warnings.filterwarnings('ignore')

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
APP = os.path.join(BASE, 'review_project', 'app.py')
sys.path.insert(0, os.path.join(BASE, 'sci_core'))

import numpy as np
import pandas as pd
import streamlit as st

src = open(APP, encoding='utf-8').read()
tree = ast.parse(src)
WANT = {
    '_qed_one', '_pains_one', '_pains_catalog', '_descriptors_one',
    '_ml_proba_one', '_cached_benchmark_b', 'compute_ml_scores', '_load_ml_scorer',
    'compute_benchmark_score', 'run_benchmark_b_analysis',
}
pieces = []
for node in tree.body:
    if isinstance(node, ast.Assign):
        targets = [t.id for t in node.targets if isinstance(t, ast.Name)]
        if any(t.startswith('COL_') or t in ('_ml_scorer', '_ml_load_error') for t in targets):
            pieces.append(ast.get_source_segment(src, node))
    elif isinstance(node, ast.FunctionDef) and node.name in WANT:
        pieces.append(ast.get_source_segment(src, node))

ns = {'pd': pd, 'np': np, 'os': os, 'sys': sys, 'time': time, 'st': st, '__file__': APP}
exec('\n\n'.join(pieces), ns)

from rdkit import Chem
from rdkit.Chem import QED, Descriptors, FilterCatalog
from rdkit.Chem.FilterCatalog import FilterCatalogParams

params = FilterCatalogParams()
for c in (FilterCatalogParams.FilterCatalogs.PAINS_A,
          FilterCatalogParams.FilterCatalogs.PAINS_B,
          FilterCatalogParams.FilterCatalogs.PAINS_C):
    params.AddCatalog(c)
catalog = FilterCatalog.FilterCatalog(params)

demo = pd.read_csv(os.path.join(BASE, 'review_project', 'EGFR_approved_full.csv'))
cb = pd.read_csv(os.path.join(BASE, 'review_project', 'chembl_egfr_benchmark_clean.csv'))
all_smiles = demo[ns['COL_SMILES']].tolist() + cb['smiles'].tolist()
print(f'验证分子数：{len(all_smiles)}（示例 71 + ChEMBL 105）')

# ---- QED / PAINS / 描述符 等价 ----
n_bad = 0
for smi in all_smiles:
    s = str(smi) if pd.notna(smi) else ''
    mol = Chem.MolFromSmiles(s) if s.strip() else None
    ref_qed = round(QED.qed(mol), 3) if mol else None
    ref_pains = ('警示' if catalog.HasMatch(mol) else '通过') if mol else None
    got_qed = ns['_qed_one'](s) if s.strip() else None
    got_pains = ns['_pains_one'](s) if s.strip() else None
    if got_qed != ref_qed or got_pains != ref_pains:
        n_bad += 1
        print(f'MISMATCH QED/PAINS: {s[:50]} ref=({ref_qed},{ref_pains}) got=({got_qed},{got_pains})')
    if mol:
        mw, lp = Descriptors.MolWt(mol), Descriptors.MolLogP(mol)
        hd, ha = Descriptors.NumHDonors(mol), Descriptors.NumHAcceptors(mol)
        ref = (mw, lp, hd, ha, mw <= 500 and lp <= 5 and hd <= 5 and ha <= 10, round(QED.qed(mol), 3))
    else:
        ref = (None,) * 6
    got = ns['_descriptors_one'](s)
    if got != ref:
        n_bad += 1
        print(f'MISMATCH descriptors: {s[:50]}')
assert n_bad == 0, f'{n_bad} 处不一致'
print('ASSERT OK: QED / PAINS / 描述符 缓存版与直接计算逐值一致')

# ---- ML 等价（单分子缓存版 vs 批量） ----
from predict import MLScorer
scorer = MLScorer()
valid = [s for s in demo[ns['COL_SMILES']] if isinstance(s, str) and s.strip()]
batch = scorer.predict_proba(valid)
one = np.array([ns['_ml_proba_one'](s) for s in valid])
assert np.allclose(batch, one, equal_nan=True), 'ML 单分子与批量不一致'
series = ns['compute_ml_scores'](demo[ns['COL_SMILES']])
ref_full = scorer.predict_proba([s if isinstance(s, str) else None for s in demo[ns['COL_SMILES']]])
assert np.allclose(series.values, ref_full, equal_nan=True)
print(f'ASSERT OK: ML 单分子缓存版与批量预测一致（{len(valid)} 分子）')

# ---- Benchmark B 等价（缓存包装 vs 原函数，seed=42 应完全确定） ----
mws, logps, hbds, hbas, lip, qeds = [], [], [], [], [], []
for smi in cb['smiles']:
    mw, lp, hd, ha, l, q = ns['_descriptors_one'](str(smi))
    mws.append(mw); logps.append(lp); hbds.append(hd); hbas.append(ha); lip.append(l); qeds.append(q)
cb[ns['COL_MW']] = mws; cb[ns['COL_LOGP']] = logps
cb[ns['COL_HBD']] = hbds; cb[ns['COL_HBA']] = hbas
cb['Lipinski符合'] = lip; cb['QED类药性'] = qeds
cb[ns['COL_SCORE']] = 0.0
dock_path = os.path.join(BASE, 'review_project', 'chembl_docking_results.csv')
if os.path.exists(dock_path):
    dd = pd.read_csv(dock_path, encoding='utf-8-sig')
    cb = cb.merge(dd[['molecule_chembl_id', 'docking_score']].dropna(), on='molecule_chembl_id', how='left')
    cb[ns['COL_DOCKING_SCORE']] = cb['docking_score']
cb['_benchmark_score'] = cb.apply(lambda r: ns['compute_benchmark_score'](r), axis=1)
scored = cb[cb['_benchmark_score'].notna()].copy()

t0 = time.perf_counter()
ref = ns['run_benchmark_b_analysis'](scored)
t_ref = time.perf_counter() - t0
t0 = time.perf_counter()
got = ns['_cached_benchmark_b'](scored)
t_got = time.perf_counter() - t0
assert ref == got, 'Benchmark B 缓存版结果不一致'
print(f'ASSERT OK: Benchmark B 缓存版与原函数结果完全一致（原函数 {t_ref:.2f}s）')
print(f"数据驱动 AUC = {got['data_driven_auc']:.3f} ± {got['data_driven_std']:.3f}")

print('\n全部等价性断言通过')