# -*- coding: utf-8 -*-
"""阶段3：复现 DGIdb 在线查询路径的排名，核查 LIDOCAINE Top1 说法。"""
import ast
import io
import json
import sys
import time
from pathlib import Path

import pandas as pd
import requests
from rdkit import Chem
from rdkit.Chem import QED, FilterCatalog
from rdkit.Chem.FilterCatalog import FilterCatalogParams

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'review_project' / 'app.py'
src = APP.read_text(encoding='utf-8')
tree = ast.parse(src)
wanted = {'apply_hard_filter', 'compute_composite_score', 'compute_evidence_confidence'}
pieces = []
for node in tree.body:
    if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) \
            and node.targets[0].id.startswith('COL_'):
        pieces.append(ast.get_source_segment(src, node))
    elif isinstance(node, ast.FunctionDef) and node.name in wanted:
        pieces.append(ast.get_source_segment(src, node))
ns = {'pd': pd}
exec('\n\n'.join(pieces), ns)
C = lambda k: ns[k]

query = '''{ genes(names: ["EGFR"]) { nodes { name interactions {
  drug { name approved conceptId immunotherapy antiNeoplastic }
  interactionScore interactionTypes { type } sources { sourceDbName } } } } }'''
resp = requests.post('https://dgidb.org/api/graphql', json={'query': query},
                     headers={'Content-Type': 'application/json'}, timeout=60)
resp.raise_for_status()
data = resp.json()
(ROOT / 'tests' / 'stage3_dgidb_egfr_raw.json').write_text(
    json.dumps(data, ensure_ascii=False, indent=1), encoding='utf-8')

rows = []
for g in data['data']['genes']['nodes']:
    for inter in g.get('interactions', []):
        d = inter.get('drug', {})
        if not d.get('approved'):
            continue
        rows.append({
            C('COL_ID'): f"MOL_{len(rows)+1:04d}",
            C('COL_DRUG_NAME'): d.get('name', ''),
            C('COL_TARGET'): g.get('name', ''),
            C('COL_SCORE'): inter.get('interactionScore', 0.0),
            C('COL_APPROVED'): True,
        })
df = pd.DataFrame(rows)
print(f'DGIdb 在线 approved 相互作用: {len(df)} 条')
print('interactionScore 分布:')
print(df[C('COL_SCORE')].describe().to_string())
print('score>1 条数:', int((df[C('COL_SCORE')] > 1).sum()),
      '| score>0.01 条数:', int((df[C('COL_SCORE')] > 0.01).sum()))

# PubChem 属性（与 app 相同 API）
props = {}
for name in df[C('COL_DRUG_NAME')].unique():
    try:
        url = ('https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/'
               f'{name}/property/MolecularWeight,XLogP,HBondDonorCount,'
               'HBondAcceptorCount,CanonicalSMILES/JSON')
        r = requests.get(url, timeout=15)
        if r.status_code == 200:
            p = r.json()['PropertyTable']['Properties'][0]
            f = lambda v: float(v) if v is not None else None
            props[name] = {C('COL_MW'): f(p.get('MolecularWeight')),
                           C('COL_LOGP'): f(p.get('XLogP')),
                           C('COL_HBD'): f(p.get('HBondDonorCount')),
                           C('COL_HBA'): f(p.get('HBondAcceptorCount')),
                           C('COL_SMILES'): p.get('ConnectivitySMILES', p.get('CanonicalSMILES', ''))}
    except Exception as e:
        print('PubChem fail:', name, e)
    time.sleep(0.25)
print(f'PubChem 属性: {len(props)}/{df[C("COL_DRUG_NAME")].nunique()}')
for col in [C('COL_MW'), C('COL_LOGP'), C('COL_HBD'), C('COL_HBA'), C('COL_SMILES')]:
    df[col] = df[C('COL_DRUG_NAME')].map(lambda n: props.get(n, {}).get(col))

df = df[(df[C('COL_MW')].fillna(0) >= 0) & (df[C('COL_MW')].fillna(0) <= 1000)]
df = df[(df[C('COL_LOGP')].fillna(-99) >= -5.0) & (df[C('COL_LOGP')].fillna(-99) <= 10.0)]
df = df[df[C('COL_HBD')].fillna(99) <= 20]
df = df[df[C('COL_HBA')].fillna(99) <= 20]
print(f'默认属性筛选后 {len(df)} 条')

df['Lipinski符合'] = df.apply(lambda r: (
    (r.get(C('COL_MW'), 0) or 0) <= 500 and (r.get(C('COL_LOGP'), 0) or 0) <= 5 and
    (r.get(C('COL_HBD'), 0) or 0) <= 5 and (r.get(C('COL_HBA'), 0) or 0) <= 10
) if pd.notna(r.get(C('COL_MW'))) else None, axis=1)
params = FilterCatalogParams()
for c in (FilterCatalogParams.FilterCatalogs.PAINS_A,
          FilterCatalogParams.FilterCatalogs.PAINS_B,
          FilterCatalogParams.FilterCatalogs.PAINS_C):
    params.AddCatalog(c)
cat = FilterCatalog.FilterCatalog(params)
qv, pv = [], []
for smi in df[C('COL_SMILES')]:
    mol = Chem.MolFromSmiles(str(smi)) if pd.notna(smi) and str(smi).strip() else None
    qv.append(round(QED.qed(mol), 3) if mol else None)
    pv.append(('警示' if cat.HasMatch(mol) else '通过') if mol else None)
df['QED类药性'], df['PAINS警示'] = qv, pv

df, log = ns['apply_hard_filter'](df)
print('filter_log:', log)
df[C('COL_COMPOSITE_SCORE')] = df.apply(lambda r: ns['compute_composite_score'](r), axis=1)
df = df.sort_values(C('COL_COMPOSITE_SCORE'), ascending=False, na_position='last')
cols = [C('COL_DRUG_NAME'), C('COL_COMPOSITE_SCORE'), C('COL_SCORE'), 'QED类药性', 'Lipinski符合']
print('\n=== 在线路径 Top 10 ===')
print(df[cols].head(10).to_string(index=False))
lid = df[df[C('COL_DRUG_NAME')].str.upper().str.contains('LIDOCAINE')]
if not lid.empty:
    rank = list(df[C('COL_DRUG_NAME')]).index(lid.iloc[0][C('COL_DRUG_NAME')]) + 1
    print(f'\nLIDOCAINE 在线路径排名: {rank}')
    print(lid[cols].to_string(index=False))
df.to_csv(ROOT / 'tests' / 'stage3_live_ranking_recalc.csv', index=False, encoding='utf-8-sig')
print('已保存 tests/stage3_live_ranking_recalc.csv')