# -*- coding: utf-8 -*-
"""阶段4 性能探针：量化 app 各计算段耗时（离线，不启动浏览器）。

用法：python tests/stage4_perf_probe.py
输出：各段耗时（秒），用于决定缓存优化点。
"""
import ast
import io
import os
import sys
import time
import warnings

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
warnings.filterwarnings('ignore')

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
APP = os.path.join(BASE, 'review_project', 'app.py')
sys.path.insert(0, os.path.join(BASE, 'sci_core'))

import numpy as np
import pandas as pd

# ---- ast 提取 app.py 中的常量与纯函数（不触发 streamlit 主流程） ----
src = open(APP, encoding='utf-8').read()
tree = ast.parse(src)
WANT_FUNCS = {
    'compute_composite_score', 'compute_benchmark_score',
    'run_benchmark_enrichment', 'run_strategy_comparison',
    'run_benchmark_b_analysis', '_match_known_inhibitor',
    'compute_evidence_confidence', 'build_evidence_chain', 'apply_hard_filter',
}
pieces = []
for node in tree.body:
    if isinstance(node, ast.Assign):
        targets = [t.id for t in node.targets if isinstance(t, ast.Name)]
        if any(t.startswith('COL_') or t == 'KNOWN_EGFR_INHIBITORS' for t in targets):
            pieces.append(ast.get_source_segment(src, node))
    elif isinstance(node, ast.FunctionDef) and node.name in WANT_FUNCS:
        pieces.append(ast.get_source_segment(src, node))

ns = {'pd': pd, 'np': np, 'os': os, 'time': time}
exec('\n\n'.join(pieces), ns)

demo = pd.read_csv(os.path.join(BASE, 'review_project', 'EGFR_approved_full.csv'))
for col in (ns['COL_SCORE'], ns['COL_MW'], ns['COL_LOGP'], ns['COL_HBD'], ns['COL_HBA'], ns['COL_DOCKING_SCORE']):
    if col in demo.columns:
        demo[col] = pd.to_numeric(demo[col], errors='coerce')
smiles = demo[ns['COL_SMILES']].tolist()
print(f'示例数据：{len(demo)} 行')


def timed(label, fn):
    t0 = time.perf_counter()
    out = fn()
    dt = time.perf_counter() - t0
    print(f'{label}: {dt:.3f}s')
    return out


from rdkit import Chem
from rdkit.Chem import QED, FilterCatalog
from rdkit.Chem.FilterCatalog import FilterCatalogParams


def build_catalog():
    params = FilterCatalogParams()
    for c in (FilterCatalogParams.FilterCatalogs.PAINS_A,
              FilterCatalogParams.FilterCatalogs.PAINS_B,
              FilterCatalogParams.FilterCatalogs.PAINS_C):
        params.AddCatalog(c)
    return FilterCatalog.FilterCatalog(params)


catalog = timed('PAINS catalog 构建（每次 rerun 重复）', build_catalog)


def qed_loop():
    vals = []
    for smi in smiles:
        mol = Chem.MolFromSmiles(str(smi)) if isinstance(smi, str) and smi.strip() else None
        vals.append(round(QED.qed(mol), 3) if mol else None)
    return vals


timed('QED 循环 71 分子（每次 rerun 重复）', qed_loop)


def pains_loop():
    flags = []
    for smi in smiles:
        mol = Chem.MolFromSmiles(str(smi)) if isinstance(smi, str) and smi.strip() else None
        flags.append(('警示' if catalog.HasMatch(mol) else '通过') if mol else None)
    return flags


timed('PAINS 循环 71 分子（每次 rerun 重复）', pains_loop)

t0 = time.perf_counter()
from predict import MLScorer
scorer = MLScorer()
print(f'ML 模型加载（进程内仅一次）: {time.perf_counter() - t0:.3f}s')
timed('ML 批量预测 71 分子（每次 rerun 重复）', lambda: scorer.predict_proba(smiles))

demo[ns['COL_ML_SCORE']] = scorer.predict_proba(smiles)
timed('综合评分 apply 71 行', lambda: demo.apply(lambda r: ns['compute_composite_score'](r), axis=1))

# ---- Benchmark A / 策略对比（页面07 每次 rerun） ----
demo[ns['COL_COMPOSITE_SCORE']] = demo.apply(lambda r: ns['compute_composite_score'](r), axis=1)
timed('Benchmark A run_benchmark_enrichment (n=71)', lambda: ns['run_benchmark_enrichment'](demo))
timed('策略对比 run_strategy_comparison (n=71)', lambda: ns['run_strategy_comparison'](demo))

# ---- Benchmark B（页面07 每次 rerun：描述符 + 50 次 CV + 消融） ----
chembl_path = os.path.join(BASE, 'review_project', 'chembl_egfr_benchmark_clean.csv')
if os.path.exists(chembl_path):
    from rdkit.Chem import Descriptors
    cb = pd.read_csv(chembl_path)
    print(f'\nChEMBL benchmark：{len(cb)} 行')

    def descriptors():
        mws, logps, hbds, hbas, lip, qeds = [], [], [], [], [], []
        for smi in cb['smiles']:
            mol = Chem.MolFromSmiles(str(smi)) if isinstance(smi, str) else None
            if mol:
                mw, lp = Descriptors.MolWt(mol), Descriptors.MolLogP(mol)
                hd, ha = Descriptors.NumHDonors(mol), Descriptors.NumHAcceptors(mol)
                mws.append(mw); logps.append(lp); hbds.append(hd); hbas.append(ha)
                lip.append(mw <= 500 and lp <= 5 and hd <= 5 and ha <= 10)
                qeds.append(round(QED.qed(mol), 3))
            else:
                mws.append(None); logps.append(None); hbds.append(None)
                hbas.append(None); lip.append(None); qeds.append(None)
        return mws, logps, hbds, hbas, lip, qeds

    mws, logps, hbds, hbas, lip, qeds = timed('Benchmark B RDKit 描述符 105 分子（每次 rerun 重复）', descriptors)
    cb[ns['COL_MW']] = mws; cb[ns['COL_LOGP']] = logps
    cb[ns['COL_HBD']] = hbds; cb[ns['COL_HBA']] = hbas
    cb['Lipinski符合'] = lip; cb['QED类药性'] = qeds
    cb[ns['COL_SCORE']] = 0.0
    dock_path = os.path.join(BASE, 'review_project', 'chembl_docking_results.csv')
    if os.path.exists(dock_path):
        dd = pd.read_csv(dock_path, encoding='utf-8-sig')
        if 'molecule_chembl_id' in dd.columns and 'docking_score' in dd.columns:
            cb = cb.merge(dd[['molecule_chembl_id', 'docking_score']].dropna(), on='molecule_chembl_id', how='left')
            cb[ns['COL_DOCKING_SCORE']] = cb['docking_score']
    cb['_benchmark_score'] = cb.apply(lambda r: ns['compute_benchmark_score'](r), axis=1)
    scored = cb[cb['_benchmark_score'].notna()].copy()
    timed('Benchmark B run_benchmark_b_analysis（CV×50 + 消融，每次 rerun 重复）',
          lambda: ns['run_benchmark_b_analysis'](scored))
else:
    print('未找到 chembl_egfr_benchmark_clean.csv，跳过 Benchmark B 计时')

print('\n探针完成')