#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Block 5 — 大规模虚拟筛选 (ChEMBL 全库)

从 ChEMBL 全库 chemreps 文件 (~240 万分子) 构建筛选库:
  1. 类药过滤 (MW 150-500 / LogP -2..6 / HBD<=5 / HBA<=10, 去盐去重)
  2. ML (ECFP4 + RandomForest) 批量打分 -> 排名
  3. 区分"已知 EGFR 活性分子"(训练集) 与"新发现候选"
  4. 输出 top 命中 + 富集指标 (召回率 / EF@1%)

诚实说明: 若用 ChEMBL 全库 chemreps 做筛选库, 模型在训练集 (已知活性) 上见过这些
分子, "召回已知活性"是转导式 (transductive) 结果, 预期很高; 若用 PubChem 随机
采样库 (--library-csv), 库与训练集重叠很小, recall/EF 分母为库内实际重叠数
(n_known_active_in_library), 此时召回数字天然偏低, 不代表模型失效。真正的
"发现"价值在 top 命中里不在训练集的新分子 (novel hits), 这些才是后续 Vina 对接的候选。

用法:
  python screen_library.py \
    --chemreps data/chembl_37_chemreps.txt.gz \
    --known data/egfr_bioactivity_v1.csv \
    --model results/final_models.pkl \
    --out-dir results_screen \
    --max-mols 200000 \
    --top-n 1000
"""
import argparse
import gzip
import json
import os
import sys
import time

import numpy as np
from rdkit import Chem, RDLogger
from rdkit.Chem import AllChem, Crippen, DataStructs, Descriptors, Lipinski

RDLogger.DisableLog("rdApp.*")

from predict import MLScorer  # noqa: E402

N_BITS = 2048
RADIUS = 2
BATCH = 20000


def _largest_fragment(mol):
    frags = Chem.GetMolFrags(mol, asMols=True)
    if not frags:
        return None
    return max(frags, key=lambda m: m.GetNumHeavyAtoms())


def canon_only(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    mol = _largest_fragment(mol)
    if mol is None:
        return None
    return Chem.MolToSmiles(mol)


def druglike_filter(smiles):
    """返回 (canonical_smiles, mw, logp) 或 (None, None, None)。"""
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None, None, None
    mol = _largest_fragment(mol)
    if mol is None:
        return None, None, None
    mw = Descriptors.MolWt(mol)
    if not (150.0 <= mw <= 500.0):
        return None, None, None
    logp = Crippen.MolLogP(mol)
    if not (-2.0 <= logp <= 6.0):
        return None, None, None
    if Lipinski.NumHDonors(mol) > 5 or Lipinski.NumHAcceptors(mol) > 10:
        return None, None, None
    return Chem.MolToSmiles(mol), mw, logp


def load_known_actives(csv_path):
    import pandas as pd

    df = pd.read_csv(csv_path, usecols=["smiles", "label"], dtype=str)
    actives = set()
    inactives = set()
    for smi, lab in zip(df["smiles"], df["label"]):
        c = canon_only(smi)
        if c is None:
            continue
        if lab == "Active":
            actives.add(c)
        else:
            inactives.add(c)
    return actives, inactives


def _cap(rows, max_mols, seed):
    if max_mols and len(rows) > max_mols:
        rng = np.random.default_rng(seed)
        idx = rng.choice(len(rows), size=max_mols, replace=False)
        rows = [rows[i] for i in sorted(idx)]
        print(f"[filter] 随机抽样保留 {len(rows)} 个分子 (seed={seed})")
    return rows


def load_chemreps(path, max_mols=0, seed=42):
    """逐行过滤 chemreps gz, 返回 [(id, canon_smiles, mw, logp), ...]。"""
    rows = []
    seen = set()
    t0 = time.time()
    with gzip.open(path, "rt", encoding="utf-8") as f:
        header = f.readline().rstrip("\n").split("\t")
        ci = header.index("chembl_id")
        si = header.index("canonical_smiles")
        for line in f:
            parts = line.rstrip("\n").split("\t")
            if len(parts) <= max(ci, si):
                continue
            canon, mw, logp = druglike_filter(parts[si])
            if canon is None or canon in seen:
                continue
            seen.add(canon)
            rows.append((parts[ci], canon, round(mw, 2), round(logp, 2)))
    print(f"[filter] 解析完成: {len(rows)} 个类药分子, 耗时 {time.time()-t0:.0f}s")
    return _cap(rows, max_mols, seed)


def load_library_csv(path, max_mols=0, seed=42):
    """读取 (cid,smiles) 类 CSV, 逐行过滤。"""
    import csv as _csv

    rows = []
    seen = set()
    t0 = time.time()
    with open(path, newline="", encoding="utf-8") as f:
        reader = _csv.DictReader(f)
        for rec in reader:
            smi = rec.get("smiles") or rec.get("canonical_smiles") or ""
            cid = rec.get("cid") or rec.get("chembl_id") or rec.get("id") or ""
            if not smi:
                continue
            canon, mw, logp = druglike_filter(smi)
            if canon is None or canon in seen:
                continue
            seen.add(canon)
            rows.append((cid, canon, round(mw, 2), round(logp, 2)))
    print(f"[filter] 解析完成: {len(rows)} 个类药分子, 耗时 {time.time()-t0:.0f}s")
    return _cap(rows, max_mols, seed)


def score_library(rows, model_path):
    scorer = MLScorer(model_path)
    model = scorer.model
    smiles = [r[1] for r in rows]
    n = len(smiles)
    proba = np.full(n, np.nan, dtype=np.float32)
    t0 = time.time()
    for start in range(0, n, BATCH):
        batch = smiles[start:start + BATCH]
        X = np.zeros((len(batch), N_BITS), dtype=np.float32)
        for i, s in enumerate(batch):
            mol = Chem.MolFromSmiles(s)
            if mol is None:
                continue
            fp = AllChem.GetMorganFingerprintAsBitVect(mol, RADIUS, N_BITS)
            DataStructs.ConvertToNumpyArray(fp, X[i])
        proba[start:start + len(batch)] = model.predict_proba(X)[:, 1]
        done = min(start + BATCH, n)
        print(f"[score] {done}/{n} ({100*done/n:.0f}%), 耗时 {time.time()-t0:.0f}s")
    return proba


def enrichment_report(proba, rows, known_active, top_n=1000):
    order = np.argsort(-proba)
    n = len(rows)
    # recall/EF 的分母必须是筛选库中实际存在的已知活性数。
    # PubChem 随机采样库与训练集重叠很小；用训练集总数 (len(known_active))
    # 做分母会严重低估 recall/EF（旧版 EF_1%=0.06 即此缺陷，见参数合理性报告 F4）。
    n_in_lib = sum(1 for r in rows if r[1] in known_active)
    top_k = [100, 1000, 10000] + ([top_n] if top_n not in (100, 1000, 10000) else [])
    report = {"n_library": n, "n_known_active_in_library": n_in_lib}
    for k in sorted(top_k):
        if k > n:
            continue
        idx = order[:k]
        hits = sum(1 for i in idx if rows[i][1] in known_active)
        report[f"known_active_in_top{k}"] = int(hits)
        report[f"recall_top{k}"] = round(hits / max(1, n_in_lib), 4)
    # EF@1%
    k1 = max(1, n // 100)
    idx = order[:k1]
    hits1 = sum(1 for i in idx if rows[i][1] in known_active)
    expected = n_in_lib * k1 / n
    report["EF_1percent"] = round(hits1 / expected, 2) if expected > 0 else None
    return report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--chemreps", default="data/chembl_37_chemreps.txt.gz")
    ap.add_argument("--library-csv", default="", help="(cid,smiles) 类 CSV 库, 优先于此文件")
    ap.add_argument("--known", default="data/egfr_bioactivity_v1.csv")
    ap.add_argument("--model", default="results/final_models.pkl")
    ap.add_argument("--out-dir", default="results_screen")
    ap.add_argument("--max-mols", type=int, default=0, help="0=全部; >0 随机抽样上限")
    ap.add_argument("--top-n", type=int, default=1000)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:  # noqa: BLE001
        pass

    os.makedirs(args.out_dir, exist_ok=True)
    known_active, known_inactive = load_known_actives(args.known)
    print(f"[known] 训练集已知活性分子 {len(known_active)} 个, 非活性 {len(known_inactive)} 个")

    if args.library_csv and os.path.exists(args.library_csv):
        rows = load_library_csv(args.library_csv, args.max_mols, args.seed)
    elif os.path.exists(args.chemreps):
        rows = load_chemreps(args.chemreps, args.max_mols, args.seed)
    else:
        print("[error] 未找到分子库文件, 请先运行 fetch_pubchem_library.py 或提供 --chemreps")
        sys.exit(1)
    if not rows:
        print("[error] 筛选库为空, 检查 --chemreps 路径")
        sys.exit(1)

    proba = score_library(rows, args.model)
    valid = ~np.isnan(proba)
    print(f"[score] 成功打分 {int(valid.sum())}/{len(rows)} 个分子")

    order = np.argsort(-proba)
    top_idx = order[:args.top_n]

    import pandas as pd

    out = []
    for rank, i in enumerate(top_idx, 1):
        smi = rows[i][1]
        out.append({
            "rank": rank,
            "chembl_id": rows[i][0],
            "smiles": smi,
            "ml_active_prob": round(float(proba[i]), 4),
            "mw": rows[i][2],
            "logp": rows[i][3],
            "known_egfr_active": smi in known_active,
            "known_egfr_inactive": smi in known_inactive,
        })
    top_df = pd.DataFrame(out)
    top_path = os.path.join(args.out_dir, "top_hits.csv")
    top_df.to_csv(top_path, index=False)

    enr = enrichment_report(proba, rows, known_active, args.top_n)
    n_novel = int((~top_df["known_egfr_active"]).sum())
    n_known = int(top_df["known_egfr_active"].sum())

    src = args.library_csv if (args.library_csv and os.path.exists(args.library_csv)) else args.chemreps
    summary = {
        "library_source": src,
        "n_druglike": len(rows),
        "n_scored": int(valid.sum()),
        "n_known_active_in_training": len(known_active),
        "n_known_active_in_library": enr["n_known_active_in_library"],
        "top_n": args.top_n,
        "top_n_known_active": n_known,
        "top_n_novel_hits": n_novel,
        "enrichment": enr,
    }
    with open(os.path.join(args.out_dir, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print("\n===== 筛选结果 =====")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print(f"\n[top10 预览]")
    print(top_df.head(10).to_string(index=False))
    print(f"\n[saved] {top_path}")
    print(f"[saved] {os.path.join(args.out_dir, 'summary.json')}")


if __name__ == "__main__":
    main()
