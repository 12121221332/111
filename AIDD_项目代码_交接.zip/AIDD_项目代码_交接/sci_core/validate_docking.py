#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Block 3 — 对接可信度验证

1. 自动计算对接盒子: 从共晶配体 (默认 AQ4 = Erlotinib) 的晶体坐标求质心与包围盒,
   替换 app 里硬编码的 box_center=[22.0, ...]。
2. Redocking 验证: 把共晶配体 Erlotinib 重新对接到受体 (1M17.pdbqt),
   计算 docked pose 与 crystal pose 的重原子 RMSD (对称校正)。
   RMSD < 2 Å 视为对接流程可信 (业界常用阈值)。
3. 打分-活性相关性: 用已有的 chembl_docking_results.csv 计算 Vina 打分与实验 pIC50
   的 Spearman 相关系数, 诚实呈现"对接打分能做什么、不能做什么"。

运行环境: 需要 rdkit + meeko + vina (即项目的 vina_env)。
用法:
  python validate_docking.py \
    --receptor ../review_project/1M17.pdbqt \
    --pdb ../review_project/1M17.pdb \
    --ligand-smiles 'COCCOc1cc2ncnc(Nc3cccc(C#C)c3)c2cc1OCCOC' \
    --ligand-resname AQ4 \
    --results-csv ../review_project/chembl_docking_results.csv \
    --out-dir results_docking
"""
import argparse
import json
import os
import sys
import tempfile

from rdkit import Chem
from rdkit.Chem import AllChem, rdMolAlign

ERLOTINIB_SMILES = "COCCOc1cc2ncnc(Nc3cccc(C#C)c3)c2cc1OCCOC"


# ---------------------------------------------------------------- 共晶配体
def extract_crystal_ligand(pdb_path, resname):
    """返回 [(element, x, y, z), ...] 重原子坐标。"""
    coords = []
    with open(pdb_path) as f:
        for line in f:
            if not line.startswith("HETATM"):
                continue
            if line[17:20].strip() != resname:
                continue
            element = line[76:78].strip()
            if not element:
                element = line[12:16].strip()[0]
            x = float(line[30:38])
            y = float(line[38:46])
            z = float(line[46:54])
            coords.append((element, x, y, z))
    return coords


def coords_to_mol(coords):
    """用重原子坐标构建带 proximity 键的 RDKit 分子 (无键级)。"""
    lines = []
    for i, (el, x, y, z) in enumerate(coords, 1):
        lines.append(
            f"HETATM{i:5d} {el:>2}   LIG A   1    {x:8.3f}{y:8.3f}{z:8.3f}"
            f"  1.00  0.00          {el:>2}"
        )
    return Chem.MolFromPDBBlock("\n".join(lines), removeHs=True,
                                sanitize=False, proximityBonding=True)


def assign_pose_to_ref(ref_mol, coords):
    """把一组 (element,x,y,z) 坐标按原子匹配挂到 ref_mol 上, 返回带 conformer 的 mol。"""
    pmol = coords_to_mol(coords)
    pmol = AllChem.AssignBondOrdersFromTemplate(ref_mol, pmol)
    match = ref_mol.GetSubstructMatch(pmol)  # match[i] = ref 原子序号, 对应 coords[i]
    conf = Chem.Conformer(len(match))
    for i, ref_idx in enumerate(match):
        conf.SetAtomPosition(ref_idx, (coords[i][1], coords[i][2], coords[i][3]))
    mol = Chem.Mol(ref_mol)
    mol.AddConformer(conf)
    return mol


def compute_box(coords, pad=8.0, min_size=18.0):
    xs = [c[1] for c in coords]
    ys = [c[2] for c in coords]
    zs = [c[3] for c in coords]
    center = [(min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2, (min(zs) + max(zs)) / 2]
    size = [
        max(min_size, max(xs) - min(xs) + pad),
        max(min_size, max(ys) - min(ys) + pad),
        max(min_size, max(zs) - min(zs) + pad),
    ]
    return center, size


# ---------------------------------------------------------------- 对接
def prepare_ligand(smiles, out_pdbqt):
    from meeko import MoleculePreparation, PDBQTWriterLegacy

    mol = Chem.AddHs(Chem.MolFromSmiles(smiles))
    AllChem.EmbedMolecule(mol, randomSeed=42)
    prep = MoleculePreparation()
    setups = prep.prepare(mol)
    if isinstance(setups, (list, tuple)):
        setups = setups[0]  # 兼容 meeko 旧版返回 list
    pdbqt, ok, err = PDBQTWriterLegacy.write_string(setups)
    if not ok:
        raise RuntimeError(f"meeko 失败: {err}")
    with open(out_pdbqt, "w") as f:
        f.write(pdbqt)
    return pdbqt


def run_docking_cli(vina_exe, receptor_pdbqt, ligand_pdbqt, center, size,
                    out_pdbqt, exhaustiveness=16, seed=42):
    """用 vina.exe 命令行对接, 返回 (best_score, out_pdbqt内容)。"""
    import subprocess

    cmd = [
        vina_exe, "--receptor", receptor_pdbqt, "--ligand", ligand_pdbqt,
        "--center_x", f"{center[0]:.3f}", "--center_y", f"{center[1]:.3f}",
        "--center_z", f"{center[2]:.3f}",
        "--size_x", f"{size[0]:.3f}", "--size_y", f"{size[1]:.3f}",
        "--size_z", f"{size[2]:.3f}",
        "--exhaustiveness", str(exhaustiveness), "--num_modes", "10",
        "--seed", str(seed),
        "--out", out_pdbqt,
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    if proc.returncode != 0:
        raise RuntimeError(f"vina 失败: {proc.stderr[:400]}")
    with open(out_pdbqt) as f:
        out_text = f.read()
    # 解析 stdout 里的打分表第一行 (best score)
    best_score = None
    for line in proc.stdout.splitlines():
        parts = line.split()
        if len(parts) >= 2 and parts[0] == "1":
            try:
                best_score = float(parts[1])
                break
            except ValueError:
                continue
    return best_score, out_text


def parse_vina_out(out_text):
    """从 vina 输出解析 scores 与各 MODEL 的原子行。"""
    scores = []
    models = []
    current = []
    for line in out_text.splitlines():
        if line.startswith("MODEL"):
            current = []
        elif line.startswith("ENDMDL"):
            models.append(current)
        elif line.startswith("REMARK VINA RESULT"):
            parts = line.split()
            if len(parts) >= 4:
                scores.append(float(parts[3]))
        elif line.startswith(("ATOM", "HETATM")):
            current.append(line)
    return scores, models


def pose_heavy_coords(atom_lines):
    """从 Vina 输出的 PDBQT 原子行提取重原子 (element,x,y,z)。"""
    coords = []
    for line in atom_lines:
        name = line[12:16].strip()
        if not name:
            continue
        element = name[0].upper()
        if element == "H":
            continue
        x = float(line[30:38])
        y = float(line[38:46])
        z = float(line[46:54])
        coords.append((element, x, y, z))
    return coords


def rmsd(mol_a, mol_b):
    """对齐后重原子 RMSD (mol_a 对齐到 mol_b)。"""
    return rdMolAlign.AlignMol(mol_a, mol_b)


# ---------------------------------------------------------------- 相关性
def correlation(results_csv):
    import numpy as np
    import pandas as pd
    from scipy import stats

    df = pd.read_csv(results_csv).dropna(subset=["docking_score", "activity_value_nM"])
    pIC50 = -np.log10(df["activity_value_nM"].values * 1e-9)
    rho, p = stats.spearmanr(df["docking_score"].values, pIC50)
    return {
        "n": int(len(df)),
        "spearman_rho_docking_vs_pIC50": round(float(rho), 3),
        "p_value": float(p),
    }


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--receptor", default="../review_project/1M17.pdbqt")
    ap.add_argument("--pdb", default="../review_project/1M17.pdb")
    ap.add_argument("--ligand-smiles", default=ERLOTINIB_SMILES)
    ap.add_argument("--ligand-resname", default="AQ4")
    ap.add_argument("--results-csv", default="../review_project/chembl_docking_results.csv")
    ap.add_argument("--out-dir", default="results_docking")
    ap.add_argument("--exhaustiveness", type=int, default=16)
    ap.add_argument("--vina-exe", default="", help="vina.exe 路径, 留空则自动搜索")
    args = ap.parse_args()

    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:  # noqa: BLE001
        pass

    if not args.vina_exe:
        candidates = [
            "../review_project/vina/vina.exe",
        ]
        args.vina_exe = next((p for p in candidates if os.path.exists(p)), "vina.exe")
    print(f"[vina] 使用 {args.vina_exe}")

    os.makedirs(args.out_dir, exist_ok=True)
    ref_mol = Chem.MolFromSmiles(args.ligand_smiles)
    n_heavy = ref_mol.GetNumHeavyAtoms()
    print(f"[ligand] {args.ligand_resname} ({args.ligand_smiles}), 重原子数 = {n_heavy}")

    # 1. 共晶配体 → 自动盒子
    crystal = extract_crystal_ligand(args.pdb, args.ligand_resname)
    print(f"[crystal] 提取 {len(crystal)} 个重原子")
    center, size = compute_box(crystal)
    print(f"[box] 自动计算 center={[round(c,2) for c in center]}  size={[round(s,2) for s in size]}")
    print(f"      (app 硬编码 center X=22.0 — 供对比)")

    # crystal 姿态挂到 ref_mol
    crystal_mol = assign_pose_to_ref(ref_mol, crystal)

    # 2. redocking
    tmpdir = tempfile.mkdtemp()
    lig_path = os.path.join(tmpdir, "ligand.pdbqt")
    out_path = os.path.join(tmpdir, "out.pdbqt")
    prepare_ligand(args.ligand_smiles, lig_path)
    print(f"[docking] 运行 Vina CLI (exhaustiveness={args.exhaustiveness}) ...")
    best_score, out_text = run_docking_cli(
        args.vina_exe, args.receptor, lig_path, center, size, out_path, args.exhaustiveness
    )
    scores, models = parse_vina_out(out_text)
    if best_score is None and scores:
        best_score = scores[0]
    print(f"[docking] best score = {best_score:.2f} kcal/mol, poses = {len(models)}")

    docked = pose_heavy_coords(models[0])
    docked_mol = assign_pose_to_ref(ref_mol, docked)
    r = rmsd(docked_mol, crystal_mol)
    print(f"[RMSD] docked vs crystal (重原子, 对称校正) = {r:.2f} Å  -> {'✅ 可信' if r <= 2.0 else '❌ 需检查'}")

    # 3. 相关性
    corr = correlation(args.results_csv)
    print(f"[correlation] {corr}")

    report = {
        "ligand_resname": args.ligand_resname,
        "ligand_smiles": args.ligand_smiles,
        "n_crystal_heavy": len(crystal),
        "box_center": [round(c, 3) for c in center],
        "box_size": [round(s, 3) for s in size],
        "docking_best_score": round(best_score, 3),
        "n_poses": len(models),
        "redocking_rmsd_A": round(r, 3),
        "rmsd_pass": bool(r <= 2.0),
        "exhaustiveness": args.exhaustiveness,
        "docking_vs_activity": corr,
    }
    with open(os.path.join(args.out_dir, "docking_validation.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print(f"[saved] {os.path.join(args.out_dir, 'docking_validation.json')}")


if __name__ == "__main__":
    main()
