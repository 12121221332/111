#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Block 2 — 分子表征 + 机器学习模型训练与评估

加载 Block 1 构建的 EGFR 生物活性基准数据集, 生成 ECFP4 (Morgan r=2) 指纹,
训练并评估三类模型:
  - LogisticRegression (线性可解释基线)
  - RandomForest       (树集成)
  - XGBoost            (梯度提升, 处理类别不平衡)

两种评估协议 (关键: 避免同系物数据泄漏):
  1. Random CV      — 分层 5-fold (乐观上界)
  2. Scaffold CV    — 按 Bemis-Murcko 骨架分组 GroupShuffleSplit (诚实估计)

报告指标: ROC-AUC / PR-AUC / Balanced Accuracy / F1 / EF@1% / EF@5% / EF@10%
以 fold 均值 ± 标准差呈现, 并保存最终模型与结果 JSON。

用法:
  python train_models.py --dataset data/egfr_bioactivity_v1.csv --out-dir results
"""
import argparse
import json
import os
import pickle
import time

import numpy as np
import pandas as pd
from rdkit import Chem, RDLogger
from rdkit.Chem import AllChem
from rdkit.Chem.Scaffolds import MurckoScaffold

RDLogger.DisableLog("rdApp.*")  # 抑制 RDKit C++ 弃用日志刷屏

from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score, balanced_accuracy_score, f1_score,
    matthews_corrcoef, roc_auc_score,
)
from sklearn.model_selection import GroupShuffleSplit, StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier

N_BITS = 2048
RADIUS = 2
SEED = 42


# ---------------------------------------------------------------- 特征
def mol_to_ecfp(smiles, n_bits=N_BITS, radius=RADIUS):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    return AllChem.GetMorganFingerprintAsBitVect(mol, radius=radius, nBits=n_bits)


def compute_features(df):
    fps = []
    kept_idx = []
    for i, smi in enumerate(df["smiles"]):
        fp = mol_to_ecfp(smi)
        if fp is None:
            continue
        arr = np.zeros((1,), dtype=np.float32)
        AllChem.DataStructs.ConvertToNumpyArray(fp, arr)
        fps.append(arr)
        kept_idx.append(i)
    X = np.vstack(fps)
    return X, df.iloc[kept_idx].reset_index(drop=True)


# ---------------------------------------------------------------- 指标
def enrichment_factor(y_true, y_score, percent):
    n = len(y_true)
    k = max(1, int(n * percent / 100.0))
    order = np.argsort(-y_score)
    top_k_active = int(y_true[order[:k]].sum())
    total_active = int(y_true.sum())
    expected = total_active * k / n
    return (top_k_active / expected) if expected > 0 else 0.0


def eval_fold(y_true, y_score):
    if len(np.unique(y_true)) < 2:
        return None
    y_pred = (y_score >= 0.5).astype(int)
    return {
        "roc_auc": roc_auc_score(y_true, y_score),
        "pr_auc": average_precision_score(y_true, y_score),
        "bacc": balanced_accuracy_score(y_true, y_pred),
        "f1": f1_score(y_true, y_pred),
        "mcc": matthews_corrcoef(y_true, y_pred),
        "ef1": enrichment_factor(y_true, y_score, 1),
        "ef5": enrichment_factor(y_true, y_score, 5),
        "ef10": enrichment_factor(y_true, y_score, 10),
    }


METRIC_KEYS = ["roc_auc", "pr_auc", "bacc", "f1", "mcc", "ef1", "ef5", "ef10"]


def make_model(name, scale_pos_weight, n_estimators):
    if name == "LogisticRegression":
        return Pipeline([
            ("scaler", StandardScaler()),
            ("clf", LogisticRegression(max_iter=2000, class_weight="balanced", random_state=SEED)),
        ])
    if name == "RandomForest":
        return RandomForestClassifier(
            n_estimators=n_estimators, class_weight="balanced", n_jobs=-1, random_state=SEED
        )
    if name == "XGBoost":
        return XGBClassifier(
            n_estimators=n_estimators, max_depth=6, learning_rate=0.1,
            scale_pos_weight=scale_pos_weight, subsample=0.8, colsample_bytree=0.8,
            tree_method="hist", n_jobs=-1, random_state=SEED, eval_metric="logloss",
        )
    raise ValueError(name)


# ---------------------------------------------------------------- 评估
def run_random_cv(X, y, models, n_splits=5):
    """分层 5-fold CV。返回 {model: {metric: (mean, std)}}。"""
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=SEED)
    results = {m: {k: [] for k in METRIC_KEYS} for m in models}
    for m, model in models.items():
        for tr, te in skf.split(X, y):
            model.fit(X[tr], y[tr])
            p = model.predict_proba(X[te])[:, 1]
            r = eval_fold(y[te], p)
            if r:
                for k in METRIC_KEYS:
                    results[m][k].append(r[k])
    return _summarize(results)


def run_scaffold_cv(X, y, scaffolds, models, n_splits=5):
    """按骨架分组 GroupShuffleSplit, 防同系物泄漏。返回同上。"""
    groups = np.array(scaffolds)
    results = {m: {k: [] for k in METRIC_KEYS} for m in models}
    for m, model in models.items():
        for seed in range(n_splits):
            gss = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=SEED + seed)
            tr, te = next(gss.split(X, y, groups=groups))
            if len(np.unique(y[te])) < 2:
                continue
            model.fit(X[tr], y[tr])
            p = model.predict_proba(X[te])[:, 1]
            r = eval_fold(y[te], p)
            if r:
                for k in METRIC_KEYS:
                    results[m][k].append(r[k])
    return _summarize(results)


def _summarize(results):
    out = {}
    for m, metrics in results.items():
        out[m] = {k: (float(np.mean(v)), float(np.std(v))) for k, v in metrics.items() if v}
    return out


def fmt_table(summary, title):
    rows = []
    rows.append(title)
    rows.append("-" * 88)
    header = f"{'model':<20}" + "".join(f"{k:>12}" for k in METRIC_KEYS)
    rows.append(header)
    for m in summary:
        cells = []
        for k in METRIC_KEYS:
            mean, std = summary[m].get(k, (float("nan"), 0.0))
            cells.append(f"{mean:>8.3f}±{std:<3.3f}")
        rows.append(f"{m:<20}" + "".join(f"{c:>12}" for c in cells))
    rows.append("")
    return "\n".join(rows)


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="data/egfr_bioactivity_v1.csv")
    ap.add_argument("--out-dir", default="results")
    ap.add_argument("--max-mw", type=float, default=900.0, help="过滤 MW 超过该值的分子 (去类药噪声)")
    ap.add_argument("--max-molecules", type=int, default=None, help="只取前 N 个分子 (快速测试)")
    ap.add_argument("--n-estimators", type=int, default=300, help="树模型树数量")
    ap.add_argument("--seed", type=int, default=SEED)
    args = ap.parse_args()

    np.random.seed(args.seed)
    os.makedirs(args.out_dir, exist_ok=True)

    df = pd.read_csv(args.dataset)
    if args.max_molecules:
        df = df.head(args.max_molecules)

    # MW 过滤
    if "MW" in df.columns and args.max_mw:
        before = len(df)
        df = df[df["MW"] <= args.max_mw].copy()
        print(f"[MW filter <= {args.max_mw}] {before} -> {len(df)} molecules")

    y = (df["label"] == "Active").astype(int).values
    print(f"[data] {len(df)} molecules | active={int(y.sum())} inactive={int((1 - y).sum())} "
          f"(prevalence={y.mean():.3f})")

    t0 = time.time()
    print("[features] generating ECFP4 fingerprints ...")
    X, df = compute_features(df)
    y = (df["label"] == "Active").astype(int).values
    print(f"  X={X.shape}  ({time.time() - t0:.1f}s)")

    # 骨架
    scaffolds = []
    n_scaffold_miss = 0
    for smi in df["smiles"]:
        try:
            sc = MurckoScaffold.MurckoScaffoldSmilesFromSmiles(smi)
        except Exception:  # noqa: BLE001
            sc = None
        if not sc:
            n_scaffold_miss += 1
            sc = smi
        scaffolds.append(sc)
    print(f"[scaffold] {len(set(scaffolds))} unique scaffolds ({n_scaffold_miss} fallback to self)")

    scale_pos_weight = float((1 - y).sum() / max(1, y.sum()))
    models = {m: make_model(m, scale_pos_weight, args.n_estimators) for m in
              ["LogisticRegression", "RandomForest", "XGBoost"]}

    out_lines = []

    out_lines.append(f"[baseline] 随机分类器: ROC-AUC=0.500, PR-AUC={y.mean():.3f} (=阳性率), EF=1.000\n")

    print("[eval] random stratified 5-fold CV ...")
    t0 = time.time()
    rand_summary = run_random_cv(X, y, models)
    print(f"  done in {time.time() - t0:.1f}s")
    out_lines.append(fmt_table(rand_summary, "== Random Stratified 5-fold CV =="))

    print("[eval] scaffold-grouped 5-split CV ...")
    t0 = time.time()
    scaf_summary = run_scaffold_cv(X, y, scaffolds, models)
    print(f"  done in {time.time() - t0:.1f}s")
    out_lines.append(fmt_table(scaf_summary, "== Scaffold-grouped CV (leakage-free) =="))

    report = "\n".join(out_lines)
    print(report)

    # 保存最终模型 (全量训练, 供后续部署/复用)
    final_models = {}
    for m, model in models.items():
        model.fit(X, y)
        final_models[m] = model
    model_path = os.path.join(args.out_dir, "final_models.pkl")
    with open(model_path, "wb") as f:
        pickle.dump(final_models, f)

    result = {
        "dataset": args.dataset,
        "n_molecules": int(len(df)),
        "n_active": int(y.sum()),
        "n_inactive": int((1 - y).sum()),
        "prevalence": float(y.mean()),
        "n_bits": N_BITS,
        "radius": RADIUS,
        "max_mw": args.max_mw,
        "random_cv": rand_summary,
        "scaffold_cv": scaf_summary,
        "final_models": model_path,
    }
    with open(os.path.join(args.out_dir, "results.json"), "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print(f"\n[saved] {model_path}")
    print(f"[saved] {os.path.join(args.out_dir, 'results.json')}")


if __name__ == "__main__":
    main()
