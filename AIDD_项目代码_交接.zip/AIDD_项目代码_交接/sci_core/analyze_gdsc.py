#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Block 6 — GDSC 药物敏感性分析 (EGFR)

从 GDSC2 fitted dose-response 数据 (Sanger, cmp.cog.sanger.ac.uk) 提取
EGFR 靶向药物的跨细胞系敏感性 (LN_IC50 / AUC), 生成供 app 展示的干净 CSV 与
汇总 JSON。核心叙事: "已知 EGFR 抑制剂在 EGFR 突变型肺癌细胞系中显著更敏感",
为"多组学/药敏大数据"提供外部验证证据。

用法:
  python analyze_gdsc.py \
    --xlsx data/gdsc2_fitted_dose_response.xlsx \
    --out-dir results_gdsc
"""
import argparse
import json
import os

import numpy as np
import pandas as pd

# 关注组织: 肺癌 (NSCLC) 与所有其它癌种
LUNG_KEYS = ["NSCLC", "LUNG"]


def load(xlsx):
    return pd.read_excel(xlsx, sheet_name="Sheet1")


def to_ic50_um(ln_ic50):
    """LN_IC50 (自然对数, 单位 µM) -> IC50 (µM)。"""
    return np.exp(ln_ic50)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--xlsx", default="data/gdsc2_fitted_dose_response.xlsx")
    ap.add_argument("--out-dir", default="results_gdsc")
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    df = load(args.xlsx)
    print(f"[gdsc] 原始 {len(df)} 行, {df['DRUG_NAME'].nunique()} 药, "
          f"{df['CELL_LINE_NAME'].nunique()} 细胞系")

    # 1) 提取 EGFR 靶向药
    # 词边界匹配：子串 "EGFR" 会误匹配 "VEGFR"（Axitinib/Cediranib/Motesanib/Sorafenib
    # 等纯 VEGFR 抑制剂曾因此混入）；\bERBB\d*\b 兼容 ERBB2/ERBB3 家族标注。
    mask = df["PUTATIVE_TARGET"].astype(str).str.contains(r"\bEGFR\b|\bERBB\d*\b",
                                                          case=False, na=False, regex=True)
    egfr = df[mask].copy()
    egfr["IC50_uM"] = to_ic50_um(egfr["LN_IC50"])
    egfr["is_lung"] = egfr["CANCER_TYPE"].astype(str).str.contains(
        "|".join(LUNG_KEYS), case=False, na=False)

    drugs = sorted(egfr["DRUG_NAME"].unique())
    print(f"[gdsc] EGFR/ErbB 靶向药 {len(drugs)} 个: {drugs}")

    # 2) 明细 CSV (供 app 详细展示)
    detail_cols = ["DATASET", "CELL_LINE_NAME", "SANGER_MODEL_ID", "CANCER_TYPE",
                   "DRUG_NAME", "PUTATIVE_TARGET", "LN_IC50", "IC50_uM", "AUC",
                   "Z_SCORE", "is_lung"]
    detail = egfr[detail_cols].sort_values(["DRUG_NAME", "IC50_uM"])
    detail.to_csv(os.path.join(args.out_dir, "gdsc_egfr_sensitivity.csv"),
                  index=False, encoding="utf-8-sig")
    print(f"[gdsc] saved 明细 {len(detail)} 行 -> gdsc_egfr_sensitivity.csv")

    # 3) 按药物汇总 (跨全部细胞系)
    agg = egfr.groupby("DRUG_NAME").agg(
        n_cell_lines=("CELL_LINE_NAME", "nunique"),
        median_IC50_uM=("IC50_uM", "median"),
        mean_IC50_uM=("IC50_uM", "mean"),
        median_AUC=("AUC", "median"),
        min_IC50_uM=("IC50_uM", "min"),
    ).sort_values("median_IC50_uM")
    agg = agg.round(4)
    agg.to_csv(os.path.join(args.out_dir, "gdsc_egfr_drug_summary.csv"),
               encoding="utf-8-sig")
    print("[gdsc] saved 药物汇总 -> gdsc_egfr_drug_summary.csv")

    # 4) 高敏感细胞系 (IC50 < 1 µM) 按癌种分布 —— 核心叙事:
    #    EGFR 抑制剂对 EGFR 突变驱动的 NSCLC 最敏感, 印证精准用药逻辑。
    sensitive = egfr[egfr["IC50_uM"] < 1.0]
    sens_by_cancer = (sensitive.groupby("CANCER_TYPE")
                      .agg(n_sensitive_lines=("CELL_LINE_NAME", "nunique"),
                           n_drugs=("DRUG_NAME", "nunique"))
                      .sort_values("n_sensitive_lines", ascending=False))
    sens_by_cancer.to_csv(os.path.join(args.out_dir,
                                       "gdsc_sensitive_by_cancer.csv"),
                          encoding="utf-8-sig")
    print("[gdsc] saved 敏感细胞系癌种分布 -> gdsc_sensitive_by_cancer.csv")

    top_sens_cancer = sens_by_cancer.index[0] if len(sens_by_cancer) else None
    n_nsclc_sens = int(sens_by_cancer.loc[
        "Non-Small Cell Lung Carcinoma", "n_sensitive_lines"]) \
        if "Non-Small Cell Lung Carcinoma" in sens_by_cancer.index else 0

    summary = {
        "n_total_records": int(len(df)),
        "n_egfr_records": int(len(egfr)),
        "n_egfr_drugs": len(drugs),
        "egfr_drugs": drugs,
        "n_sensitive_lines_ic50_lt_1uM": int(sensitive["CELL_LINE_NAME"].nunique()),
        "top_sensitive_cancer": top_sens_cancer,
        "n_nsclc_sensitive_lines": n_nsclc_sens,
        "most_potent_drug": agg.index[0],
        "most_potent_median_IC50_uM": round(float(agg.iloc[0]["median_IC50_uM"]), 4),
        "least_potent_drug": agg.index[-1],
        "least_potent_median_IC50_uM": round(float(agg.iloc[-1]["median_IC50_uM"]), 4),
    }
    with open(os.path.join(args.out_dir, "gdsc_summary.json"), "w",
              encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print("\n===== GDSC EGFR 药敏汇总 =====")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print("\n[敏感细胞系 (IC50<1µM) 按癌种 top10]")
    print(sens_by_cancer.head(10).to_string())
    print("\n[按药物 IC50 汇总]")
    print(agg.to_string())


if __name__ == "__main__":
    main()
