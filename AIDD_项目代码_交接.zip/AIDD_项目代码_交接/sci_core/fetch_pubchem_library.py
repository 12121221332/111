#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Block 5a — 从 PubChem 批量获取大规模分子库

PubChem 是 NCBI 的化合物数据库 (~1.8 亿化合物)。本脚本通过 PUG-REST
listkey 工作流随机采样 CID, 批量拉取 IsomericSMILES + MolecularWeight,
预过滤 MW 150-500 (类药区间), 去重后输出筛选库 CSV 供 screen_library.py 打分。

用法:
  python fetch_pubchem_library.py \
    --target 200000 \
    --out data/pubchem_library.csv \
    --seed 42
"""
import argparse
import csv
import os
import random
import sys
import time

import requests

BASE = "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound"
CID_MAX = 185_000_000
BATCH = 5000
PROPS = "IsomericSMILES,MolecularWeight,XLogP"


def _find_col(header, *keys):
    for k in keys:
        for i, h in enumerate(header):
            if h.lower() == k.lower():
                return i
    return None


def fetch_batch(cids, retries=3):
    """返回 [(cid, smiles, mw, xlogp), ...] 或 None。"""
    url = f"{BASE}/cid/property/{PROPS}/CSV"
    cid_str = ",".join(map(str, cids))
    for attempt in range(retries):
        try:
            r = requests.post(url, data={"cid": cid_str}, timeout=90)
            if r.status_code == 200 and r.text.startswith('"CID"'):
                return _parse_csv_text(r.text)
            if r.status_code == 200 or r.status_code == 202:
                # 大列表返回 ListKey
                lk = None
                try:
                    lk = r.json().get("ListKey")
                except Exception:
                    lk = None
                if lk:
                    return _fetch_listkey(lk, retries)
            time.sleep(2 * (attempt + 1))
        except requests.RequestException:
            time.sleep(2 * (attempt + 1))
    return None


def _fetch_listkey(listkey, retries=3):
    url = f"{BASE}/listkey/{listkey}/property/{PROPS}/CSV"
    for attempt in range(retries):
        try:
            r = requests.get(url, timeout=120)
            if r.status_code == 200 and r.text.startswith('"CID"'):
                return _parse_csv_text(r.text)
            time.sleep(2 * (attempt + 1))
        except requests.RequestException:
            time.sleep(2 * (attempt + 1))
    return None


def _parse_csv_text(text):
    lines = text.splitlines()
    if not lines:
        return []
    header = next(csv.reader([lines[0]]))
    ci = _find_col(header, "CID")
    si = _find_col(header, "IsomericSMILES", "CanonicalSMILES",
                   "ConnectivitySMILES", "SMILES")
    wi = _find_col(header, "MolecularWeight", "Molecular_Weight", "Weight")
    xi = _find_col(header, "XLogP", "LogP")
    if ci is None or si is None or wi is None:
        return []
    rows = []
    for line in lines[1:]:
        try:
            parts = next(csv.reader([line]))
        except Exception:
            continue
        if len(parts) <= max(ci, si, wi):
            continue
        cid = parts[ci].strip()
        smi = parts[si].strip()
        if not cid or not smi:
            continue
        mw = parts[wi].strip()
        xlogp = parts[xi].strip() if xi is not None else ""
        rows.append((cid, smi, mw, xlogp))
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", type=int, default=200000, help="目标类药分子数")
    ap.add_argument("--out", default="data/pubchem_library.csv")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--max-cids", type=int, default=1000000, help="最多尝试的 CID 数")
    ap.add_argument("--mw-min", type=float, default=150.0)
    ap.add_argument("--mw-max", type=float, default=500.0)
    args = ap.parse_args()

    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:  # noqa: BLE001
        pass

    rng = random.Random(args.seed)
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)

    # 先取一批验证连通性
    sample = [rng.randint(1, CID_MAX) for _ in range(50)]
    batch = fetch_batch(sample)
    if batch is None:
        print("[error] 无法连接 PubChem, 请检查网络")
        sys.exit(1)

    seen = set()
    out_rows = []
    tried = 0
    t0 = time.time()

    def flush(rows):
        with open(args.out, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["cid", "smiles", "mw", "xlogp"])
            for r in rows:
                w.writerow(r)

    # 处理首批
    for r in batch:
        tried += 1
        cid, smi, mw, xlogp = r
        try:
            mwv = float(mw)
        except ValueError:
            continue
        if not (args.mw_min <= mwv <= args.mw_max):
            continue
        if smi in seen:
            continue
        seen.add(smi)
        out_rows.append((cid, smi, mw, xlogp))

    while len(out_rows) < args.target and tried < args.max_cids:
        cids = [rng.randint(1, CID_MAX) for _ in range(BATCH)]
        batch = fetch_batch(cids)
        if batch is None:
            print("[warn] 批次失败, 继续...")
            time.sleep(3)
            continue
        for r in batch:
            tried += 1
            cid, smi, mw, xlogp = r
            try:
                mwv = float(mw)
            except ValueError:
                continue
            if not (args.mw_min <= mwv <= args.mw_max):
                continue
            if smi in seen:
                continue
            seen.add(smi)
            out_rows.append((cid, smi, mw, xlogp))
        print(f"[fetch] 已尝试 {tried} 个 CID, 得到类药分子 {len(out_rows)} 个, "
              f"耗时 {time.time()-t0:.0f}s", flush=True)
        time.sleep(0.3)

    flush(out_rows)
    print(f"[done] 输出 {len(out_rows)} 个类药分子 -> {args.out}")


if __name__ == "__main__":
    main()
