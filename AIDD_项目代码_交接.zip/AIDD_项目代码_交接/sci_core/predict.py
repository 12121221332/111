#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
ML 活性预测推理模块 (供 Streamlit app 集成)

加载块2 (train_models.py) 训练的最终模型 (ECFP4 指纹 + RandomForest/XGBoost),
对任意 SMILES 列表预测"EGFR 活性"概率 (0~1, 越接近 1 越可能是活性分子)。

设计要点:
  - 与训练保持一致的指纹参数 (Morgan radius=2, nBits=2048)
  - 非法/缺失 SMILES 返回 NaN, 不中断批量预测
  - load_scorer() 懒加载单例; 模型文件或依赖缺失时返回 None (app 侧优雅降级)

用法:
  from predict import load_scorer
  scorer = load_scorer()
  proba = scorer.predict_proba(["COCCOc1cc2ncnc(Nc3cccc(C#C)c3)c2cc1OCCOC", ...])
"""
import os
import pickle

import numpy as np
from rdkit import Chem, RDLogger
from rdkit.Chem import AllChem, DataStructs

RDLogger.DisableLog("rdApp.*")

N_BITS = 2048
RADIUS = 2
DEFAULT_MODEL_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  "results", "final_models.pkl")


class MLScorer:
    def __init__(self, model_path=DEFAULT_MODEL_PATH, model_name="RandomForest"):
        with open(model_path, "rb") as f:
            self.models = pickle.load(f)
        if model_name not in self.models:
            model_name = next(iter(self.models))
        self.model = self.models[model_name]
        self.model_name = model_name
        self.model_path = model_path

    @staticmethod
    def _fingerprint(smiles):
        if not isinstance(smiles, str) or not smiles.strip():
            return None
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            return None
        fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius=RADIUS, nBits=N_BITS)
        arr = np.zeros((1,), dtype=np.float32)
        DataStructs.ConvertToNumpyArray(fp, arr)
        return arr

    def predict_proba(self, smiles_list):
        """返回 np.array, 长度与输入一致, 非法 SMILES 对应 NaN。"""
        n = len(smiles_list)
        X = np.zeros((n, N_BITS), dtype=np.float32)
        valid = np.zeros(n, dtype=bool)
        for i, s in enumerate(smiles_list):
            fp = self._fingerprint(s)
            if fp is not None:
                X[i] = fp
                valid[i] = True
        proba = np.full(n, np.nan, dtype=np.float32)
        if valid.any():
            proba[valid] = self.model.predict_proba(X[valid])[:, 1]
        return proba


_scorer = None


def load_scorer(model_path=None):
    """懒加载单例; 失败返回 None (供 app 优雅降级)。"""
    global _scorer
    if _scorer is not None:
        return _scorer
    try:
        _scorer = MLScorer(model_path) if model_path else MLScorer()
    except Exception:  # noqa: BLE001
        _scorer = None
    return _scorer


if __name__ == "__main__":
    demo = [
        "COCCOc1cc2ncnc(Nc3cccc(C#C)c3)c2cc1OCCOC",  # Erlotinib
        "COc1cc2ncnc(Nc3ccc(F)c(Cl)c3)c2cc1OCCCN1CCOCC1",  # Gefitinib
        "CCO",  # 明显非药物
        "not_a_smiles",
    ]
    s = load_scorer()
    if s is None:
        print("模型加载失败, 请先运行 train_models.py 生成 results/final_models.pkl")
    else:
        print(f"模型: {s.model_name} ({s.model_path})")
        for smi, p in zip(demo, s.predict_proba(demo)):
            print(f"  {smi[:40]:<42} -> p(Active) = {p:.3f}")
