#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Block 5c — top 命中批量 Vina 对接精筛

对 screen_library.py 的 top 命中跑 AutoDock Vina, 完成
"ML 预筛 (20万) -> 对接精筛 (top-N)" 两级漏斗闭环。

复用 validate_docking.py 里已验证的 prepare_ligand / run_docking_cli;
对接盒子用共晶配体 (Erlotinib/AQ4) 自动算出的 center/size (RMSD 已验 <2Å)。

用法:
  python dock_top_hits.py \
    --top-hits results_screen/top_hits.csv \
    --n 100 \
    --out-dir results_screen/docking \
    --exhaustiveness 8
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile
import time

import pandas as pd

from validate_docking import prepare_ligand, run_docking_cli

BOX_CENTER = [21.697, 0.303, 52.093]
BOX_SIZE = [23.709, 18.0, 18.0]
RECEPTOR = "../review_project/1M17.pdbqt"
VINA_CANDIDATES = [
    "../review_project/vina/vina.exe",
]


def find_vina():
    for p in VINA_CANDIDATES:
        if os.path.exists(p):
            return p
    return "vina.exe"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--top-hits", default="results_screen/top_hits.csv")
    ap.add_argument("--n", type=int, default=100)
    ap.add_argument("--out-dir", default="results_screen/docking")
    ap.add_argument("--exhaustiveness", type=int, default=8)
    ap.add_argument("--receptor", default=RECEPTOR)
    ap.add_argument("--vina-exe", default="")
    args = ap.parse_args()

    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:  # noqa: BLE001
        pass

    vina = args.vina_exe or find_vina()
    print(f"[vina] {vina}")
    print(f"[box] center={BOX_CENTER} size={BOX_SIZE}")
    os.makedirs(args.out_dir, exist_ok=True)

    top = pd.read_csv(args.top_hits).head(args.n)
    results = []
    t0 = time.time()
    for i, (_, row) in enumerate(top.iterrows(), 1):
        smi = row["smiles"]
        cid = row.get("chembl_id", row.get("cid", ""))
        ml = row.get("ml_active_prob", None)
        try:
            with tempfile.TemporaryDirectory() as td:
                lig = os.path.join(td, "l.pdbqt")
                out = os.path.join(td, "o.pdbqt")
                prepare_ligand(smi, lig)
                score, _ = run_docking_cli(
                    vina, args.receptor, lig, BOX_CENTER, BOX_SIZE, out, args.exhaustiveness
                )
            if score is not None:
                results.append({
                    "rank_ml": i, "chembl_id": cid, "smiles": smi,
                    "ml_active_prob": ml, "docking_score": round(score, 3),
                })
                print(f"[dock] {i}/{args.n} ML={ml:.3f} -> vina={score:.2f} kcal/mol "
                      f"({time.time()-t0:.0f}s)", flush=True)
            else:
                results.append({
                    "rank_ml": i, "chembl_id": cid, "smiles": smi,
                    "ml_active_prob": ml, "docking_score": None,
                })
                print(f"[dock] {i}/{args.n} 无打分", flush=True)
        except Exception as e:  # noqa: BLE001
            print(f"[dock] {i}/{args.n} 失败: {str(e)[:120]}", flush=True)
            results.append({
                "rank_ml": i, "chembl_id": cid, "smiles": smi,
                "ml_active_prob": ml, "docking_score": None,
            })

    df = pd.DataFrame(results)
    df_scored = df.dropna(subset=["docking_score"]).sort_values("docking_score")
    out_csv = os.path.join(args.out_dir, "docking_results.csv")
    df_scored.to_csv(out_csv, index=False)

    if len(df_scored):
        summary = {
            "n_requested": int(args.n),
            "n_docked": int(len(df_scored)),
            "box_center": BOX_CENTER,
            "box_size": BOX_SIZE,
            "exhaustiveness": args.exhaustiveness,
            "best_docking_score": round(float(df_scored["docking_score"].min()), 3),
            "median_docking_score": round(float(df_scored["docking_score"].median()), 3),
            "n_docked_below_neg9": int((df_scored["docking_score"] < -9.0).sum()),
        }
    else:
        summary = {"n_requested": int(args.n), "n_docked": 0}

    with open(os.path.join(args.out_dir, "docking_summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print("\n===== 对接精筛结果 =====")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if len(df_scored):
        print("\n[对接排名 top10]")
        print(df_scored.head(10)[["rank_ml", "chembl_id", "ml_active_prob", "docking_score"]].to_string(index=False))
    print(f"\n[saved] {out_csv}")


if __name__ == "__main__":
    main()
