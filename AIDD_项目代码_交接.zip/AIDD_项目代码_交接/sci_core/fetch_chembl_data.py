#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Block 1 — ChEMBL EGFR 生物活性数据获取与基准构建

从 ChEMBL REST API 拉取人类 EGFR (CHEMBL203) 的 IC50 / Ki / Kd 活性数据,
清洗后构建可用于分类模型训练与评估的基准数据集。

标注规则 (参考 ChEMBL 机器学习基准的通用做法, 阈值可调):
  - Active   : IC50/Ki/Kd <= 1 uM  (关系为 =, ~, <, <=)
  - Inactive : IC50/Ki/Kd >= 10 uM (关系为 =, ~, >, >=)
  - 灰区 (1uM < 值 < 10uM) 丢弃, 避免标签噪声

去重规则:
  - 分子先经 RDKit 去盐 + 规范化 SMILES
  - 同一 SMILES 取所有测量中最强 (最小值) 的活性作为该分子的代表活性

输出:
  - data/raw_activities_v1.csv    (精简后的原始记录)
  - data/egfr_bioactivity_v1.csv  (去重 + 标注后的基准数据集)
  - data/egfr_bioactivity_v1_report.txt (构建摘要)
"""
import argparse
import os
import sys
import time

import numpy as np
import pandas as pd
import requests
from rdkit import Chem
from rdkit.Chem import Descriptors

CHEMBL_BASE = "https://www.ebi.ac.uk/chembl/api/data"
TARGET_CHEMBL_ID = "CHEMBL203"          # 人类 EGFR (Epidermal growth factor receptor)
STANDARD_TYPES = ["IC50", "Ki", "Kd"]
ACTIVE_NM = 1000.0                      # <= 1 uM 判为 Active
INACTIVE_NM = 10000.0                   # >= 10 uM 判为 Inactive

UNIT_TO_NM = {
    "M": 1e9, "mM": 1e6, "uM": 1e3, "µM": 1e3, "μM": 1e3,
    "nM": 1.0, "pM": 1e-3, "fM": 1e-6,
}

KEEP_FIELDS = [
    "activity_id", "molecule_chembl_id", "molecule_pref_name",
    "canonical_smiles", "standard_type", "standard_value",
    "standard_units", "standard_relation", "pchembl_value",
    "assay_type", "assay_chembl_id", "target_chembl_id", "target_pref_name",
    "bao_label", "document_chembl_id", "year",
]


def fetch_activities(target_id, standard_types, page_size=1000, max_records=None, timeout=60):
    """分页拉取指定靶点的活性记录, 带重试。"""
    records = []
    offset = 0
    total = None
    while True:
        params = {
            "target_chembl_id": target_id,
            "standard_type__in": ",".join(standard_types),
            "limit": page_size,
            "offset": offset,
        }
        data = None
        for attempt in range(4):
            try:
                r = requests.get(f"{CHEMBL_BASE}/activity.json", params=params, timeout=timeout)
                r.raise_for_status()
                data = r.json()
                break
            except Exception as e:  # noqa: BLE001
                if attempt == 3:
                    raise
                time.sleep(2 ** attempt)

        acts = data.get("activities", [])
        if total is None:
            total = data.get("page_meta", {}).get("total_count", 0)
            print(f"  [info] 总记录数 (IC50/Ki/Kd): {total}")
        if not acts:
            break
        records.extend(acts)
        offset += len(acts)
        print(f"  fetched {offset}/{total} ...")
        if max_records is not None and len(records) >= max_records:
            records = records[:max_records]
            break
        if offset >= total:
            break
    return records


def to_nm(value, unit):
    if value is None or unit is None:
        return np.nan
    factor = UNIT_TO_NM.get(unit)
    if factor is None:
        return np.nan
    try:
        return float(value) * factor
    except (TypeError, ValueError):
        return np.nan


def classify(value_nm, relation, active_nm=ACTIVE_NM, inactive_nm=INACTIVE_NM):
    """根据活性值与关系符号返回 Active / Inactive / None(灰区)。"""
    if value_nm is None or np.isnan(value_nm):
        return None
    if relation in ("=", "~"):
        if value_nm <= active_nm:
            return "Active"
        if value_nm >= inactive_nm:
            return "Inactive"
        return None
    if relation in ("<", "<="):
        return "Active" if value_nm <= active_nm else None
    if relation in (">", ">="):
        return "Inactive" if value_nm >= inactive_nm else None
    return None


def build_dataset(raw_df, active_nm=ACTIVE_NM, inactive_nm=INACTIVE_NM):
    """清洗、去重、标注。返回 (dataset, 摘要dict)。"""
    df = raw_df.copy()

    # 1. 单位统一为 nM
    df["value_nm"] = df.apply(lambda r: to_nm(r.get("standard_value"), r.get("standard_units")), axis=1)
    df = df.dropna(subset=["value_nm"]).copy()

    # 2. 关系符号归一化
    df["relation"] = df["standard_relation"].fillna("=").astype(str).str.strip()

    # 3. 去盐 + 规范化 SMILES (保留最大片段, 自包含实现, 不依赖 RDKit Data 文件)
    def canon_smiles(smi):
        if not isinstance(smi, str) or not smi.strip():
            return None
        mol = Chem.MolFromSmiles(smi)
        if mol is None:
            return None
        frags = Chem.GetMolFrags(mol, asMols=True)
        if not frags:
            return None
        if len(frags) > 1:
            mol = max(frags, key=lambda m: m.GetNumHeavyAtoms())
        if mol is None or mol.GetNumHeavyAtoms() == 0:
            return None
        return Chem.MolToSmiles(mol, canonical=True, isomericSmiles=True)

    df["clean_smiles"] = df["canonical_smiles"].map(canon_smiles)
    df = df.dropna(subset=["clean_smiles"]).copy()

    # 4. 逐条分类
    df["label_raw"] = df.apply(
        lambda r: classify(r["value_nm"], r["relation"], active_nm, inactive_nm), axis=1
    )

    # 5. 按 SMILES 去重: 取最强 (最小) 活性作为代表, 并记录对应关系符号
    df["is_active_rank"] = df["label_raw"].map({"Active": 0, "Inactive": 1}).fillna(2)
    df = df.sort_values(["value_nm", "is_active_rank"])

    grouped = df.groupby("clean_smiles", as_index=False).agg(
        molecule_chembl_id=("molecule_chembl_id", lambda s: s.iloc[0]),
        molecule_pref_name=("molecule_pref_name", lambda s: s.iloc[0]),
        min_value_nm=("value_nm", "min"),
        min_relation=("relation", "first"),
        min_standard_type=("standard_type", "first"),
        n_measurements=("activity_id", "count"),
        assay_types=("assay_type", lambda s: ",".join(sorted({str(x) for x in s if pd.notna(x)}))),
        n_active_meas=("label_raw", lambda s: int((s == "Active").sum())),
        n_inactive_meas=("label_raw", lambda s: int((s == "Inactive").sum())),
    )

    # 6. 用最强测量的值与关系做最终标注
    grouped["label"] = grouped.apply(
        lambda r: classify(r["min_value_nm"], r["min_relation"], active_nm, inactive_nm), axis=1
    )
    grouped = grouped.dropna(subset=["label"]).copy()

    # 7. 计算分子量等基础描述符 (供后续 decoy 匹配与可视化)
    def calc_mw(smi):
        mol = Chem.MolFromSmiles(smi)
        return Descriptors.MolWt(mol) if mol else np.nan

    grouped["MW"] = grouped["clean_smiles"].map(calc_mw)

    grouped = grouped.rename(columns={"clean_smiles": "smiles"})
    final_cols = [
        "smiles", "molecule_chembl_id", "molecule_pref_name", "label",
        "min_value_nm", "min_relation", "min_standard_type", "MW",
        "n_measurements", "n_active_meas", "n_inactive_meas", "assay_types",
    ]
    grouped = grouped[final_cols]

    summary = {
        "raw_records": len(raw_df),
        "unique_molecules": len(grouped),
        "n_active": int((grouped["label"] == "Active").sum()),
        "n_inactive": int((grouped["label"] == "Inactive").sum()),
        "active_median_nM": float(grouped.loc[grouped["label"] == "Active", "min_value_nm"].median()),
        "inactive_median_nM": float(grouped.loc[grouped["label"] == "Inactive", "min_value_nm"].median()),
        "records_after_unit_conv": int(len(df)),
    }
    return grouped, summary


def main():
    ap = argparse.ArgumentParser(description="ChEMBL EGFR bioactivity dataset builder")
    ap.add_argument("--target", default=TARGET_CHEMBL_ID)
    ap.add_argument("--out-dir", default=os.path.join(os.path.dirname(__file__), "data"))
    ap.add_argument("--version", default="v1")
    ap.add_argument("--max-records", type=int, default=None, help="仅拉取前 N 条 (测试用)")
    ap.add_argument("--active-nm", type=float, default=ACTIVE_NM)
    ap.add_argument("--inactive-nm", type=float, default=INACTIVE_NM)
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    print(f"== 拉取 {args.target} ({','.join(STANDARD_TYPES)}) ==")
    records = fetch_activities(args.target, STANDARD_TYPES, max_records=args.max_records)

    raw = pd.DataFrame([{k: rec.get(k) for k in KEEP_FIELDS} for rec in records])
    print(f"  原始记录: {len(raw)}")

    dataset, summary = build_dataset(raw, args.active_nm, args.inactive_nm)

    raw_path = os.path.join(args.out_dir, f"raw_activities_{args.version}.csv")
    ds_path = os.path.join(args.out_dir, f"egfr_bioactivity_{args.version}.csv")
    report_path = os.path.join(args.out_dir, f"egfr_bioactivity_{args.version}_report.txt")

    raw.to_csv(raw_path, index=False)
    dataset.to_csv(ds_path, index=False)

    lines = [
        "ChEMBL EGFR 基准数据集构建报告",
        "=" * 40,
        f"靶点: {args.target} (人类 EGFR)",
        f"标准类型: {', '.join(STANDARD_TYPES)}",
        f"标注阈值: Active <= {ACTIVE_NM:.0f} nM, Inactive >= {INACTIVE_NM:.0f} nM",
        f"原始记录数: {len(raw)}",
        f"单位转换后有效记录: {summary['records_after_unit_conv']}",
        f"去重后唯一分子: {summary['unique_molecules']}",
        f"  Active  : {summary['n_active']} (中位 {summary['active_median_nM']:.1f} nM)",
        f"  Inactive: {summary['n_inactive']} (中位 {summary['inactive_median_nM']:.1f} nM)",
        f"数据集文件: {os.path.basename(ds_path)}",
    ]
    with open(report_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    print("\n".join(lines))


if __name__ == "__main__":
    main()
