#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Block 5b — 命中结构分析

把 screen_library.py 的 top 命中与"已知 EGFR 小分子激酶抑制剂"参照集做
ECFP4 Tanimoto 相似度分析, 并与随机基线对比, 量化"ML 排序富集 EGFR 药效团"
这一核心结论。

用法:
  python analyze_hits.py \
    --top-hits results_screen/top_hits.csv \
    --reference ../review_project/EGFR_approved_full.csv \
    --library data/pubchem_library.csv \
    --n-baseline 2000 \
    --out results_screen/hit_analysis.json
"""
import argparse
import json
import os
import sys

import numpy as np
from rdkit import Chem, RDLogger
from rdkit.Chem import AllChem, DataStructs

RDLogger.DisableLog("rdApp.*")

EGFR_TKI_NAMES = {
    "AFATINIB", "AFATINIB DIMALEATE",
    "GEFITINIB",
    "ERLOTINIB", "ERLOTINIB HYDROCHLORIDE",
    "LAPATINIB", "LAPATINIB DITOSYLATE",
    "OSIMERTINIB", "OSIMERTINIB MESYLATE",
    "DACOMITINIB", "DACOMITINIB ANHYDROUS",
    "NERATINIB", "NERATINIB MALEATE",
    "VANDETANIB",
    "OLMUTINIB",
    "LAZERTINIB", "LAZERTINIB MESYLATE",
    "MOBOCERTINIB", "MOBOCERTINIB SUCCINATE",
    "SUNVOZERTINIB",
    "TUCATINIB",
    "SEVABERTINIB",
    "BRIGATINIB",
}


def largest_fragment(mol):
    frags = Chem.GetMolFrags(mol, asMols=True)
    return max(frags, key=lambda m: m.GetNumHeavyAtoms()) if frags else None


def canon(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    mol = largest_fragment(mol)
    return Chem.MolToSmiles(mol) if mol else None


def fp(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    return AllChem.GetMorganFingerprintAsBitVect(mol, 2, 2048)


def load_reference(csv_path):
    import pandas as pd

    df = pd.read_csv(csv_path, dtype=str)
    smis = []
    for name, smi in zip(df["药物名称"], df["SMILES"]):
        if str(name).upper() in EGFR_TKI_NAMES:
            c = canon(smi)
            if c:
                smis.append(c)
    return list(dict.fromkeys(smis))


def max_sim_to_ref(query_fp, ref_fps):
    best = 0.0
    for rf in ref_fps:
        s = DataStructs.TanimotoSimilarity(query_fp, rf)
        if s > best:
            best = s
    return best


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--top-hits", default="results_screen/top_hits.csv")
    ap.add_argument("--reference", default="../review_project/EGFR_approved_full.csv")
    ap.add_argument("--library", default="data/pubchem_library.csv")
    ap.add_argument("--n-baseline", type=int, default=2000)
    ap.add_argument("--out", default="results_screen/hit_analysis.json")
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()

    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:  # noqa: BLE001
        pass

    ref_smis = load_reference(args.reference)
    ref_fps = [fp(s) for s in ref_smis]
    ref_fps = [f for f in ref_fps if f is not None]
    print(f"[ref] 已知 EGFR TKI 参照集: {len(ref_fps)} 个")

    import pandas as pd

    top = pd.read_csv(args.top_hits)
    top_sims = []
    for smi in top["smiles"]:
        f = fp(smi)
        top_sims.append(max_sim_to_ref(f, ref_fps) if f else 0.0)
    top["max_sim_to_known_egfr_tki"] = [round(s, 4) for s in top_sims]

    # 随机基线: 从库里随机抽 n_baseline 个
    lib = pd.read_csv(args.library, usecols=["smiles"])
    rng = np.random.default_rng(args.seed)
    sample = lib["smiles"].sample(n=min(args.n_baseline, len(lib)),
                                  random_state=args.seed).tolist()
    base_sims = []
    for smi in sample:
        f = fp(smi)
        base_sims.append(max_sim_to_ref(f, ref_fps) if f else 0.0)

    def stats(sims):
        a = np.array(sims)
        return {
            "n": int(len(a)),
            "mean": round(float(a.mean()), 4),
            "median": round(float(np.median(a)), 4),
            "pct_gt_0.4": round(float((a > 0.4).mean() * 100), 2),
            "pct_gt_0.5": round(float((a > 0.5).mean() * 100), 2),
            "pct_gt_0.6": round(float((a > 0.6).mean() * 100), 2),
            "max": round(float(a.max()), 4),
        }

    top_stats = stats(top_sims)
    base_stats = stats(base_sims)

    def fold(t):
        b = base_stats[f"pct_gt_{t}"]
        if b <= 0:
            return "inf"
        return round(top_stats[f"pct_gt_{t}"] / b, 1)

    enrich = {f"fold_gt_{t}": fold(t) for t in ["0.4", "0.5", "0.6"]}

    report = {
        "reference_egfr_tkis": ref_smis,
        "top_hits": top_stats,
        "random_baseline": base_stats,
        "enrichment_fold": enrich,
    }
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    top_out = os.path.join(os.path.dirname(args.out), "top_hits_with_sim.csv")
    top.to_csv(top_out, index=False)

    print("\n===== 命中结构分析 =====")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    print(f"\n[saved] {args.out}")
    print(f"[saved] {top_out}")


if __name__ == "__main__":
    main()
