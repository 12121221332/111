# AIDD 虚拟筛选系统 — 科学核心方法学说明

> 本文档是参赛作品"科学可信度"部分的叙事底稿, 对应答辩时"你的方法为什么可信、创新在哪"的回答。
> 所有数据均由 `sci_core/` 下的脚本可复现生成, 对应三个实验块。

---

## 0. 一句话定位

系统用 **三类证据** 对靶点候选小分子排序, 并用**真实训练的机器学习模型**作为主评分器,
用**分子对接**作为结构互补证据, 用**启发式规则**做可解释性兜底。核心科学贡献是:
**在一个防数据泄漏的基准上, 证明了机器学习模型对 EGFR 活性分子的排序能力显著优于分子对接。**

---

## 1. 数据: ChEMBL 人类 EGFR 生物活性基准

**来源**: ChEMBL REST API, 靶点 `CHEMBL203`(人类 EGFR)。
> 注意: 常见错误是取 `CHEMBL3608`(小鼠 EGFR), 本项目已确认并规避。

**检索**: IC50 / Ki / Kd 三种标准活性类型, 共 30,661 条原始记录。

**清洗规则** (`fetch_chembl_data.py`):
- 单位统一为 nM; 无效 SMILES 丢弃;
- 去盐: 保留最大重原子片段(自包含实现, 不依赖 RDKit Data 文件);
- 去重: 同一规范化 SMILES 取**最强(最小)活性**作为代表。

**标注阈值**:
| 标签 | 条件 |
|------|------|
| Active | IC50/Ki/Kd ≤ 1 μM(关系 = / ~ / < / ≤) |
| Inactive | ≥ 10 μM(关系 = / ~ / > / ≥) |
| 灰区 | 1~10 μM 之间, 丢弃(避免标签噪声) |

**结果**: 11,909 个唯一分子(9,598 Active / 2,311 Inactive), 过滤 MW>900 后 11,820 个(9,527 / 2,293)。

---

## 2. 模型: 分子指纹 + 机器学习活性分类

**表征**: ECFP4(Morgan, radius=2, 2048-bit)指纹 — 领域标准基线。

**模型** (`train_models.py`):
- LogisticRegression(线性可解释基线, class_weight=balanced)
- RandomForest(300 棵树, class_weight=balanced)
- XGBoost(300 棵树, scale_pos_weight 处理不平衡, hist 加速)

**评估协议(关键——防数据泄漏)**:
1. **Random CV**: 分层 5-fold(乐观上界);
2. **Scaffold CV**: 按 Bemis-Murcko 骨架分组的 GroupShuffleSplit(5 次), 同骨架分子绝不跨训练/测试, 是**诚实估计**。

**结果(scaffold CV, 泄漏安全)**:

| 模型 | ROC-AUC | PR-AUC | EF@10% |
|------|---------|--------|--------|
| 随机基线 | 0.500 | 0.806(=阳性率) | 1.000 |
| LogisticRegression | 0.874 ± 0.011 | 0.963 | 1.216 |
| **RandomForest** | **0.948 ± 0.006** | **0.987** | 1.228 |
| XGBoost | 0.936 ± 0.005 | 0.983 | 1.223 |

**解读**: 在保证同骨架不泄漏的前提下, RF 达到 ROC-AUC 0.948、PR-AUC 0.987,
说明"分子结构本身携带了强 EGFR 活性信号", 远高于随机水平。

---

## 3. 对接可信度: redocking RMSD + 打分-活性相关性

**自动盒子** (`validate_docking.py`): 从共晶配体 AQ4(Erlotinib)晶体坐标求质心与包围盒,
得到 `center=[21.70, 0.30, 52.09], size=[23.71, 18.0, 18.0]`。
项目原代码硬编码 `center_x=22.0`, 与自动计算一致, 说明原盒子基本正确。

**Redocking 验证**: 将 Erlotinib 重新对接到受体 1M17, 计算 docked vs crystal 重原子 RMSD(对称校正):

| 指标 | 结果 | 判据 |
|------|------|------|
| 对接最佳打分 | -6.35 kcal/mol | — |
| **重原子 RMSD** | **1.78 Å** | **< 2 Å, 通过** |

RMSD < 2 Å 是行业常用阈值, 证明**对接流程能重现晶体结合姿态, 流程可信**。

**打分-活性相关性**(105 个已对接 ChEMBL 分子):
- Spearman rho(对接打分 vs pIC50)= **-0.516**(p = 1.8×10⁻⁸)。

**关键结论**: 对接打分方向正确且统计显著, 但强度(0.52)远低于机器学习模型(0.95 AUC)。
这正好支撑作品的叙事:**对接提供"结合方式是否合理"的结构证据, 但不适合单独作为排序器**。

---

## 4. 多证据融合的定位

```
               ┌─────────────────────────────────────┐
  候选分子 ──► │  ML 模型 (主评分)   ROC-AUC 0.948    │
               │  + 分子对接 (结构验证) RMSD 1.78 Å    │
               │  + 启发式规则 (可解释兜底)           │
               └─────────────────────────────────────┘
```

- **机器学习**: 从 ~12k 分子的实验活性学到的"结构→活性"映射, 排序能力强;
- **分子对接**: 不依赖训练数据、可对任意新化合物给出结合姿态与打分, 做结构合理性校验;
- **启发式规则**(QED/Lipinski/DGIdb 证据): 保证每一步可解释, 便于向评委与用户讲清楚"为什么"。

三者互补, 而非重复。

---

## 5. 局限性与诚实声明(答辩加分项)

1. **标签噪声**: 不同实验来源的 IC50 不可完全直接比较; "取最强活性"可能略乐观。已在文档中披露。
2. **类别不平衡**: 阳性率 80%, PR-AUC 相对基线(0.806)的提升才是关键, 不能只看绝对值。
3. **对接打分≠亲和力**: 相关系数仅 0.52, 绝对打分值(-6.35 kcal/mol)不与 nM 级亲和力严格对应。
4. **数据规模**: 12k 分子对 GNN 仍偏小, 指纹+树模型在当前规模下更稳健(这也是选择 RF/XGB 而非直接上 GNN 的原因)。
5. **泛化**: 模型仅在 EGFR 单靶点验证, 跨靶点迁移能力未评估。

---

## 6. 超大规模虚拟筛选 + 药敏大数据 (块5/6)

**两级漏斗 (ML 预筛 → 对接精筛)**:

1. **分子库**: PubChem PUG-REST 随机采样 ~20 万分子, 类药过滤 (MW 150-500 / LogP -2..6 / HBD≤5 / HBA≤10, 去盐去重) 后保留 **190,966 个类药分子** (`fetch_pubchem_library.py` → `data/pubchem_library.csv`)。
2. **ML 预筛** (`screen_library.py`): 用块2训练的 RandomForest (ECFP4, 2048-bit) 对 19 万分子批量打分, 输出 top 2000 命中 (`results_screen/top_hits.csv`)。
3. **结构富集证据** (`analyze_hits.py`): top 命中与 15 个已知 EGFR TKI 的 ECFP4 Tanimoto 相似度 (T>0.4) 占比 **2.3%**, 随机基线仅 **0.04%**, **富集 57.5×** — 证明 ML 排序富集 EGFR 药效团结构, 而非随机猜测。
4. **对接精筛** (`dock_top_hits.py`): 对 top 命中跑 AutoDock Vina (exhaustiveness=8, 盒子复用块3 redocking 验证的 1M17 盒子), 输出 `results_screen/docking/docking_results.csv`。

**GDSC 药敏大数据佐证** (`analyze_gdsc.py`):

- 数据源: Sanger GDSC2 fitted dose-response (24.2 万条记录, `data/gdsc2_fitted_dose_response.xlsx`)。
- 提取 12 个 EGFR/ErbB 靶向药的跨细胞系 IC50/AUC (`results_gdsc/gdsc_egfr_sensitivity.csv`)。
- 核心结论: 288 个高敏感细胞系 (IC50<1µM) 中, **非小细胞肺癌 (NSCLC) 最多 (20 个)**, 印证 EGFR 突变驱动 NSCLC 的精准用药逻辑; 最强药 Foretinib 中位 IC50 = 2.55 µM。

**叙事价值**: 把"单靶点 12k 分子建模"放大到"19 万分子超大规模筛选 + 24 万条药敏大数据外部验证", 且每一步都有量化富集/一致性证据支撑。

---

## 7. 复现方式

```bash
# 环境: ml_env (Python 3.10, numpy/scipy/sklearn/xgboost/rdkit/meeko/gemmi/requests)
python fetch_chembl_data.py                    # 块1: 生成 data/egfr_bioactivity_v1.csv
python train_models.py                         # 块2: 生成 results/results.json + final_models.pkl
python validate_docking.py                     # 块3: 生成 results_docking/docking_validation.json
python fetch_pubchem_library.py --target 200000 # 块5: 生成 data/pubchem_library.csv
python screen_library.py --library-csv data/pubchem_library.csv --top-n 2000  # 块5: ML 预筛
python analyze_hits.py --top-hits results_screen/top_hits.csv                 # 块5: 结构富集
python dock_top_hits.py --top-hits results_screen/top_hits.csv --n 100        # 块5: 对接精筛
python analyze_gdsc.py --xlsx data/gdsc2_fitted_dose_response.xlsx            # 块6: GDSC 药敏
```

> 注意: 本机 `vina_env` 的 numpy 线性代数库(BLAS)已损坏(任何 `np.dot` 都会崩溃),
> 会同时影响 app 内 sklearn 逻辑回归(benchmark B)。**需在 app 侧修复**, 建议:
> `pip install --force-reinstall numpy`(或改用干净的 `ml_env` 运行 app)。
