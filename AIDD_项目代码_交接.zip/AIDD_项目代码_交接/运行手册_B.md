# 运行手册（同学 B 本机验证版）

> 验证日期：2026-11-19 · 机器：Windows 11 / Python 3.12.10（用户级安装，非 conda）
> 本手册替代交接说明中基于队友 A 机器（C:\Users\Lenovo\...）的运行方式。

## 一、环境（已验证）

单一 Python 环境即可同时跑 app 与 sci_core 脚本，不需要交接说明中的 vina_env/ml_env 双环境。

```bash
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
```

关键版本：streamlit 1.67.0 / pandas 3.1.1 / numpy 2.5.5 / scikit-learn 1.9.1 / rdkit 2026.9.2 / xgboost 3.4.1（完整见 requirements.txt）。

已知兼容性说明：
- `sci_core/results/final_models.pkl` 由 sklearn 1.7.2 训练，1.9.1 加载时有 InconsistentVersionWarning，实测预测正常（Erlotinib/Gefitinib p≈0.987，乙醇 p≈0.010，非法 SMILES 返回 NaN）。长期建议用 train_models.py 在本机重训或导出 ONNX。
- numpy BLAS 健康（矩阵乘法实测通过），交接文档中的 BLAS 损坏问题在本机不存在。
- streamlit `use_container_width` 弃用告警：已将 app.py 中 16 处替换为 `width='stretch'`。

## 二、启动

```bash
cd review_project
python -m streamlit run app.py
```

浏览器打开 http://localhost:8501。Vina 二进制已随包（review_project/vina/vina.exe），无需另装。

## 三、端到端验证结果（2026-11-19 实测）

| 页面 | 验证内容 | 结果 |
|------|---------|------|
| 01 Research Center | 渲染、四层架构展示 | ✅ |
| 02 Target Intelligence | DGIdb 在线查询 EGFR → 83 条相互作用；PubChem 61/83 属性 | ✅（修复 BUG-01 后） |
| 02 大规模虚拟筛选 tab | 190,966 / 2,000 / 富集 57.5× / 对接 100 分子最佳 -9.14 / GDSC 288 敏感系 NSCLC Foretinib | ✅ 与交接数字一致 |
| 03 Candidate Discovery | 筛选 49 条、风险筛查、加权融合评分、QED、证据链 | ✅（修复 BUG-01 后） |
| 04 Molecular Validation | Gefitinib 真实 Vina 对接，9 姿态，图表+表格 | ✅（修复 BUG-02 后） |
| 05 AI Research Agent | 无 Key 时友好提示不崩溃 | ✅ 渲染；LLM 实测待 API Key |
| 06 Evidence Report | 报告概览、Top10、证据链、Markdown 下载 | ✅ |
| 07 System Validation | Benchmark A 实时计算 + Benchmark B 105 分子消融/数据驱动 AUC 0.845±0.089 | ✅ |

ML 模型在 app 内确认真实加载（服务端日志可见 predict.py 加载记录），非静默降级。

## 四、已修复（阶段 1+2，详见 tests/测试用例_阶段2.md）

1. **BUG-01**（崩溃级）：PubChem 新 API 将 MolecularWeight 等字段改为字符串返回，原代码未转型导致页面 03 筛选 `TypeError` 崩溃。已在 `query_pubchem_properties` API 边界加显式 float 转换。
2. **BUG-02**（显示级）：对接姿态对比表的表头与数据行分多个 `st.markdown` 渲染，表格散架为竖线文本。已合并为单个 markdown 块。
3. **BUG-03**（崩溃级，边界测试发现）：上传 CSV 数值列含字符串（如 MW="abc"）时页面 03 筛选崩溃。已加 `_coerce_numeric_columns`（`pd.to_numeric(errors='coerce')`），上传/示例两条载入路径统一强转。
4. **BUG-04**（逻辑级，边界测试发现）：`apply_hard_filter` 只排除空 SMILES，`not_a_smiles` 等不可解析字符串漏网并参与排名。已改为 RDKit 解析校验；对 71 条示例数据无副作用（离线验证 0 条非空不可解析）。
5. **REPRO-01**：Vina 未固定种子导致同分子两次对接 -5.73 vs -5.14。app 与 sci_core（validate_docking.py / dock_top_hits.py）均加 `--seed 42`；回归三次对接 9 姿态分数逐一相同。
6. **UX-01**：单分子对接结果切页即丢。已存 `st.session_state['last_docking']`，切页保留；载入新数据时清除。
7. **待核查-04**：rdkit 2026.9.2 中 `FilterCatalogParams` 需从 `rdkit.Chem.FilterCatalog` 导入，原 ImportError 被 `except: pass` 吞掉 → PAINS 恒 0。已修 import（2 处）；71 条数据实测通过 35 / 警示 2，页面 03/06 口径一致。
8. **盒子对齐**：app 对接盒子默认值改为 redocking 验证值 center=[21.697, 0.303, 52.093]、size=[23.709, 18, 18]（RMSD 1.78Å）；Gefitinib 打分由 ~-5.7 提升至 -6.60 kcal/mol。
9. **静默吞错可见化**：ML 模型加载失败显示原因警告（`_ml_load_error`）；QED/PAINS 失败显示 st.warning。
10. **硬编码路径清理**：移除 `D:\nobody\vina\vina.exe` 等队友机器路径（app + sci_core）。

## 五、已知问题（阶段 3 已审计，详见 参数合理性报告.md）

阶段 3（2026-11-19）完成参数与阈值合理性审计，结论：

- **F1（高）**：LIDOCAINE Top1 在 DGIdb 在线路径复现成功（61.0 vs AFATINIB 59.9；示例数据路径 Top1 为 AFATINIB 72.5）。根因：无对接时 QED 有效权重 41.7% 主导排序，ML 活性概率（唯一靶点特异性证据，同数据集单维 AUC 0.928 vs 启发式 0.525）不参与融合。
- **F2（高）**：Benchmark A AUC 随 DGIdb 在线评分漂移（0.552→0.569），不可复现；KNOWN_EGFR_INHIBITORS 漏盐型/新药且与 analyze_hits.py 名单不一致；修正标签后 AUC 反降至 0.525，公式弱点坐实。
- **F3（中，BUG-05）**：analyze_gdsc.py 子串过滤把 VEGFR 误匹配为 EGFR，"12 个 EGFR/ErbB 药"实为 8 个；288 敏感系中 5 个仅由误匹配药贡献（NSCLC 20 不受影响）；Foretinib "最强药" 系多激酶抑制剂跨癌种中位数口径，叙事需降级；无突变分层。
- **F4（中）**：summary.json EF_1%=0.06 分母误用训练集活性总数 9598（非库内重叠），指标无效；57.5× 结构富集数字有效但口径是 Tanimoto 相似度非活性召回。
- 跨版本 pickle（sklearn 1.7.2 → 1.9.1）有告警，建议重训或导出 ONNX（未变）。

修复优先级与逐项阈值出处见 [参数合理性报告.md](参数合理性报告.md) 第六/七节；复算脚本与数据快照在 tests/stage3_*。

## 五之二、阶段 3 A 档修复（2026-11-19 已完成并回归）

1. **A1**：KNOWN_EGFR_INHIBITORS 统一为 28 个（同步 analyze_hits.py，剔除 HER2 选择性 SEVABERTINIB），新增全名/首词匹配 `_match_known_inhibitor`，Benchmark A 与策略对比共用。
2. **A2**：页面 02 GDSC 指标与 caption 改为数据驱动 + 口径限定；随包旧结果自动显示 ⚠ VEGFR 误匹配降级提示（块 6 重跑后消失）；补"未做突变分层"声明。
3. **A3**：ML 活性概率纳入综合评分，新权重 **Docking 30% + ML 30% + QED 15% + Lipinski 10% + DGIdb 15%**（活性证据 60%）；证据链新增 ML 条目；Benchmark 专用评分仍排除 ML（防标签泄漏，页面已写明）。
4. **A4**：analyze_gdsc.py 靶点过滤改词边界正则 `\bEGFR\b|\bERBB\d*\b`（结果文件待块 6 重跑）。
5. **A5**：screen_library.py EF/recall 分母改库内实际重叠，字段拆分 `n_known_active_in_training` / `n_known_active_in_library`。
6. **A6**：筛选面板 MW/LogP/HBD/HBA 统一"缺失保留"语义（NaN 交 Stage 1 处理）。

**修复后新基线（替代第三/四节中的旧数字，浏览器 + 离线双重回归通过）：**

| 项目 | 旧基线 | 新基线 |
|------|--------|--------|
| 示例数据筛选后 | 37 条 | **71 条 → Stage 1 保留 50/71**（排除 21 条无效 SMILES） |
| 示例路径 Top1 | AFATINIB 72.5 | **AFATINIB 85.3**（High），Top5 全为 EGFR-TKI |
| 在线路径 Top1 | LIDOCAINE 61.0 | **AFATINIB 77.1**；LIDOCAINE 降至 32/49（39.9） |
| LIDOCAINE 示例排名 | 第 3 | **34/50（39.7）** |
| Benchmark A（示例） | n=37，AUC 0.552 | **n=50，阳性 25，AUC 0.368**（页面如实显示"富集效果有限"警示，属预期诚实结果） |

回归脚本：tests/stage3_fix_verify.py（输出 stage3_fix_demo_ranking.csv / stage3_fix_live_ranking.csv）；用例记录见 tests/测试用例_阶段3.md。B 档（块 5/6 重跑、Benchmark 数据快照、突变分层）移交同学 A/C。

## 五之三、阶段 4 UI/性能/缓存 + 可复现性（2026-11-19 已完成）

1. **性能优化（低风险，不动业务逻辑）**：QED/PAINS/ML/描述符改为按 SMILES 缓存（`st.cache_data`），PAINS catalog 用 `st.cache_resource`，Benchmark B 分析结果按数据内容缓存。优化前页面 03 每次滑块 rerun 重算 ~0.6s、页面 07 Benchmark B 每次 rerun ~2.2s；缓存命中后不再重算。等价性逐值验证通过（176 分子 QED/PAINS/描述符/ML/Benchmark B 全部一致），浏览器回归结果不变。
2. **UX-02**：页面 06 下载报告原将缺失值输出为 `nan`/`None`，已统一格式化为 `N/A`。
3. **可复现性核对**：随机入口种子全覆盖（Vina seed=42、CV/抽样 random_state=42、sci_core SEED）；requirements.txt 13 包与本机精确一致。
4. **UI 一致性**：旧基线数字无文案残留（旧四指标权重仅保留于 Benchmark 专用防泄漏评分）；页面 03/06/07 均为新权重口径。

详见 [tests/测试用例_阶段4.md](tests/测试用例_阶段4.md)。移交打包见 [移交清单_同学C.md](移交清单_同学C.md)（含答辩数字口径卡、B/C 档待办、pickle 重训步骤）。

## 六、待补

- 智谱 GLM-4-Flash API Key（侧边栏填入）后实测页面 01/05/06 的 LLM 功能（用户指示暂缓）。
- 复现 sci_core 块 5/6 需另行下载 pubchem_library.csv 与 GDSC2 xlsx（app 展示用预计算结果，不受影响）。